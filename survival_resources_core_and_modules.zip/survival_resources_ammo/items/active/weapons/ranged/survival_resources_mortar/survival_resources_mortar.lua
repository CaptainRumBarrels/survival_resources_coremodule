require "/scripts/util.lua"
require "/scripts/vec2.lua"
require "/items/active/weapons/weapon.lua"

function init()
  activeItem.setCursor("/cursors/reticle0.cursor")
  animator.setGlobalTag("paletteSwaps", config.getParameter("paletteSwaps", ""))

  self.weapon = Weapon:new()

  self.weapon:addTransformationGroup("weapon", {0,0}, 0)
  self.weapon:addTransformationGroup("muzzle", self.weapon.muzzleOffset, 0)

  local primaryAbility = getPrimaryAbility()
  self.weapon:addAbility(primaryAbility)

  local secondaryAbility = getAltAbility(self.weapon.elementalType)
  if secondaryAbility then
    self.weapon:addAbility(secondaryAbility)
  end
  
  self.weapon:init()
  animator.setAnimationState("mountMode", "up")
end

function update(dt, fireMode, shiftHeld)
  self.weapon:update(dt, fireMode, shiftHeld)
  mcontroller.controlModifiers({
	  --runningSuppressed = true,
	  --movementSuppressed = true
    })
  activeItem.setFrontArmFrame("jump.1")
  activeItem.setBackArmFrame("swim.3")
	
  if mcontroller.crouching() then
    animator.setAnimationState("mountMode", "down")
	activeItem.setArmAngle(-25)
	mcontroller.controlCrouch()
	--status.setPersistentEffects("onEquiptStatus", { "prone" })
  else
    animator.setAnimationState("mountMode", "up")
	--status.setPersistentEffects("onEquiptStatus", { "starmageddon_heavy" })
  end
end

function uninit()
  self.weapon:uninit()
  status.clearPersistentEffects("onEquiptStatus")
end
