function init()
  
end

function update()
	
  --world.spawnItem("survival_resources_hydrogenfuel", entity.position(), itemCount)
  --world.spawnItem("survival_resources_oxygenboost", entity.position(), itemCount)
	
  local maxValue = 4
  local minValue = 1
  local itemCount = player.hasCountOfItem("survival_resources_refinedpcb")
	
  self.randomizeItem = math.floor(math.random(minValue, maxValue))
  self.randomizeQuantity = math.floor(math.random(3, 5))
	
  if self.randomizeItem == 1 then world.spawnItem("stickofram", entity.position(), 1)
    elseif self.randomizeItem == 2 then world.spawnItem("siliconboard", entity.position(), 1)
    elseif self.randomizeItem == 3 then world.spawnItem("metallicmaterial", entity.position(), self.randomizeQuantity)
    elseif self.randomizeItem == 4 then world.spawnItem("wire", entity.position(), 1)
  end

  item.consume(1)

  --item.consume(itemCount)
end

function uninit()

end
