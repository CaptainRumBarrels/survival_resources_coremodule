require "/scripts/util.lua"
require "/scripts/vec2.lua"

function init()
  self.fabricatorBenchPosition = config.getParameter("fabricatorbench")
  self.fabricatorRefineryPosition = config.getParameter("fabricatorrefinery")
  self.fabricatorMiddlePlaced = false
  self.fabricatorTopPlaced = false
end

function update()
  placeObects()
end

function placeObects()
  if not self.fabricatorMiddlePlaced  then
    for _, fabricatorRefineryPosition in ipairs(self.fabricatorRefineryPosition) do
      fabricatorRefineryPosition = vec2.add(fabricatorRefineryPosition, entity.position())
	  if object.direction() == -1 then
	    world.placeObject("survival_resources_fabricator2", fabricatorRefineryPosition, -1)
	  elseif object.direction() == 1 then
		world.placeObject("survival_resources_fabricator2", fabricatorRefineryPosition, 1)
	  end
    end
	self.fabricatorMiddlePlaced = true
  end	

  if not self.fabricatorTopPlaced and self.fabricatorMiddlePlaced then
    for _, fabricatorBenchPosition in ipairs(self.fabricatorBenchPosition) do
      fabricatorBenchPosition = vec2.add(fabricatorBenchPosition, entity.position())
	  if object.direction() == -1 then
	    world.placeObject("survival_resources_fabricatortop", fabricatorBenchPosition, -1)
	  elseif object.direction() == 1 then
		world.placeObject("survival_resources_fabricatortop", fabricatorBenchPosition, 1)
	  end
    end
	self.fabricatorTopPlaced = true
  end
end
