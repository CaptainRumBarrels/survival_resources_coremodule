function init()
  script.setUpdateDelta(5)
  self.healingRate = config.getParameter("resourcePercentage") / effect.duration()
end

function update(dt)
  status.modifyResourcePercentage("energy", (self.healingRate / 100) * dt)
end

function uninit()
  
end
