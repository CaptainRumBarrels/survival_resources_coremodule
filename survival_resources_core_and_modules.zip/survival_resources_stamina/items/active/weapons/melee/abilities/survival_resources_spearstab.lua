require "/items/active/weapons/melee/abilities/survival_resources_meleeslash.lua"

-- Spear stab attack
-- Extends normal melee attack and adds a hold state
survival_resources_spearstab = MeleeSlash:new()

function survival_resources_spearstab:init()
  MeleeSlash.init(self)

  self.holdDamageConfig = sb.jsonMerge(self.damageConfig, self.holdDamageConfig)
  self.holdDamageConfig.baseDamage = self.holdDamageMultiplier * self.damageConfig.baseDamage
end

function survival_resources_spearstab:fire()
  MeleeSlash.fire(self)

  if self.fireMode == "primary" and self.allowHold ~= false then
    self:setState(self.hold)
  end
end

function survival_resources_spearstab:hold()
  self.weapon:setStance(self.stances.hold)
  self.weapon:updateAim()

  while self.fireMode == "primary" do
    local damageArea = partDamageArea("blade")
    self.weapon:setDamage(self.holdDamageConfig, damageArea)
    coroutine.yield()
  end

  self.cooldownTimer = self:cooldownTime()
end
