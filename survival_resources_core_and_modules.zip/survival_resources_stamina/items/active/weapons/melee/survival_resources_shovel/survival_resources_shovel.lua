require "/scripts/util.lua"
require "/scripts/vec2.lua"
require "/items/active/weapons/weapon.lua"

-- Pickaxe primary ability
ShovelDig = WeaponAbility:new()

function ShovelDig:init()
  self.weapon:setStance(self.stances.idle)

  self.id1 = "dirt"
  self.id2 = "drydirt"
  self.id3 = "sand"
  self.id4 = "sand2"
  self.id5 = "drysand"
  self.id6 = "gravel"
  self.id7 = "mud"
  self.id8 = "slush"
  self.id9 = "snow"
	
  self.area = 0.6
  self.damage = 0.8

  self.weapon.onLeaveAbility = function()
    self.weapon:setStance(self.stances.idle)
    self:setAnimationStates(self.onLeaveAnimationStates)
  end
end

function ShovelDig:setAnimationStates(states)
  for stateType, state in pairs(states or {}) do
    animator.setAnimationState(stateType, state)
  end
end

-- Ticks on every update regardless if this is the active ability
function ShovelDig:update(dt, fireMode, shiftHeld)
  WeaponAbility.update(self, dt, fireMode, shiftHeld)

  --left to right, top to bottom in 3x3 grid
	
  self:hitPositions()
	
  if not self.weapon.currentAbility and self:shouldFire() then
    self:setState(self.windup)
  end  
end

function ShovelDig:bladeReady()
  for stateType, state in pairs(self.requisiteAnimationStates or {}) do
    if animator.animationState(stateType) ~= state then
      return false
    end
  end
  return true
end

function ShovelDig:canFire()
  return not status.resourceLocked("energy") and status.resourcePositive("energy")
end

function ShovelDig:shouldFire()
  return self:canFire() and self.fireMode == self.activatingFireMode
end

-- State: windup
function ShovelDig:windup()
  self.weapon:setStance(self.stances.windup)
  self.weapon:updateAim()

  if not self:bladeReady() then
    self:setAnimationStates(self.windupAnimationStates)
  end

  while not self:bladeReady() do
    coroutine.yield()
  end

  if self:shouldFire() then
    self:setState(self.fire)
  end
end

-- State: fire
function ShovelDig:fire()
  local entityPosition = world.entityPosition(activeItem.ownerEntityId())
  local distance1 = vec2.mag(world.distance(entityPosition, self.hitPosition1))
  local distance2 = vec2.mag(world.distance(entityPosition, self.hitPosition2))
  local distance3 = vec2.mag(world.distance(entityPosition, self.hitPosition3))
  local distance4 = vec2.mag(world.distance(entityPosition, self.hitPosition4))
  local distance5 = vec2.mag(world.distance(entityPosition, self.hitPosition5))
  local distance6 = vec2.mag(world.distance(entityPosition, self.hitPosition6))
  local distance7 = vec2.mag(world.distance(entityPosition, self.hitPosition7))
  local distance8 = vec2.mag(world.distance(entityPosition, self.hitPosition8))
  local distance9 = vec2.mag(world.distance(entityPosition, self.hitPosition9))
	
  if distance1 > self.toolRange then coroutine.yield() self:setState(self.windup) return end
  if distance2 > self.toolRange then coroutine.yield() self:setState(self.windup) return end
  if distance3 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
  if distance4 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
  if distance5 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
  if distance6 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
  if distance7 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
  if distance8 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
  if distance9 > self.toolRange then coroutine.yield() self:setState(self.windup) return end	
	
  status.overConsumeResource("survival_resources_resourceStamina", 0.075)
			
  self:mineForeground()
  self:mineBackground()

  self.weapon:setStance(self.stances.fire)
  self.weapon:updateAim()

  coroutine.yield()

  animator.playSound("fire")
	
  util.wait(self.stances.fire.duration)

  if self:shouldFire() then
    self:setState(self.windup)
  end
end

function ShovelDig:uninit()
  self:setAnimationStates(self.inactiveAnimationStates)
end

function ShovelDig:hitPositions()
  self.hitPosition1 = vec2.add(activeItem.ownerAimPosition(), {-1.0, 1.0})
  self.hitPosition2 = vec2.add(activeItem.ownerAimPosition(), {0.0, 1.0})
  self.hitPosition3 = vec2.add(activeItem.ownerAimPosition(), {1.0, 1.0})
  self.hitPosition4 = vec2.add(activeItem.ownerAimPosition(), {-1.0, 0.0})
  self.hitPosition5 = vec2.add(activeItem.ownerAimPosition(), {0.0, 0.0})
  self.hitPosition6 = vec2.add(activeItem.ownerAimPosition(), {1.0, 0.0})
  self.hitPosition7 = vec2.add(activeItem.ownerAimPosition(), {-1.0, -1.0})
  self.hitPosition8 = vec2.add(activeItem.ownerAimPosition(), {0.0, -1.0})
  self.hitPosition9 = vec2.add(activeItem.ownerAimPosition(), {1.0, -1.0}) 
end

function ShovelDig:mineForeground()
 --mp; Material Position
  self.mp1 = world.material(self.hitPosition1, "foreground")
  self.mp2 = world.material(self.hitPosition2, "foreground")
  self.mp3 = world.material(self.hitPosition3, "foreground")
  self.mp4 = world.material(self.hitPosition4, "foreground")
  self.mp5 = world.material(self.hitPosition5, "foreground")
  self.mp6 = world.material(self.hitPosition6, "foreground")
  self.mp7 = world.material(self.hitPosition7, "foreground")
  self.mp8 = world.material(self.hitPosition8, "foreground")
  self.mp9 = world.material(self.hitPosition9, "foreground")

  if self.fireMode == "primary" then
  if self.mp1 == self.id1  or self.mp1 == self.id2 or self.mp1 == self.id3 or self.mp1 == self.id4 or self.mp1 == self.id5 or self.mp1 == self.id6 or self.mp1 == self.id7 or self.mp1 == self.id8 or self.mp1 == self.id9 then
    world.damageTileArea(self.hitPosition1, self.area, "foreground", self.hitPosition1, "blockish", self.damage, 99)
  end
  if self.mp2 == self.id1  or self.mp2 == self.id2 or self.mp2 == self.id3 or self.mp2 == self.id4 or self.mp2 == self.id5 or self.mp2 == self.id6 or self.mp2 == self.id7 or self.mp2 == self.id8 or self.mp2 == self.id9 then
    world.damageTileArea(self.hitPosition2, self.area, "foreground", self.hitPosition2, "blockish", self.damage, 99)
  end
  if self.mp3 == self.id1  or self.mp3 == self.id2 or self.mp3 == self.id3 or self.mp3 == self.id4 or self.mp3 == self.id5 or self.mp3 == self.id6 or self.mp3 == self.id7 or self.mp3 == self.id8 or self.mp3 == self.id9 then
    world.damageTileArea(self.hitPosition3, self.area, "foreground", self.hitPosition3, "blockish", self.damage, 99)
  end
  if self.mp4 == self.id1  or self.mp4 == self.id2 or self.mp4 == self.id3 or self.mp4 == self.id4 or self.mp4 == self.id5 or self.mp4 == self.id6 or self.mp4 == self.id7 or self.mp4 == self.id8 or self.mp4 == self.id9 then
    world.damageTileArea(self.hitPosition4, self.area, "foreground", self.hitPosition4, "blockish", self.damage, 99)
  end
  if self.mp5 == self.id1  or self.mp5 == self.id2 or self.mp5 == self.id3 or self.mp5 == self.id4 or self.mp5 == self.id5 or self.mp5 == self.id6 or self.mp5 == self.id7 or self.mp5 == self.id8 or self.mp5 == self.id9 then
    world.damageTileArea(self.hitPosition5, self.area, "foreground", self.hitPosition5, "blockish", self.damage, 99)
  end
  if self.mp6 == self.id1  or self.mp6 == self.id2 or self.mp6 == self.id3 or self.mp6 == self.id4 or self.mp6 == self.id5 or self.mp6 == self.id6 or self.mp6 == self.id7 or self.mp6 == self.id8 or self.mp6 == self.id9 then
    world.damageTileArea(self.hitPosition6, self.area, "foreground", self.hitPosition6, "blockish", self.damage, 99)
  end
  if self.mp7 == self.id1  or self.mp7 == self.id2 or self.mp7 == self.id3 or self.mp7 == self.id4 or self.mp7 == self.id5 or self.mp7 == self.id6 or self.mp7 == self.id7 or self.mp7 == self.id8 or self.mp7 == self.id9 then
    world.damageTileArea(self.hitPosition7, self.area, "foreground", self.hitPosition7, "blockish", self.damage, 99)
  end
  if self.mp8 == self.id1  or self.mp8 == self.id2 or self.mp8 == self.id3 or self.mp8 == self.id4 or self.mp8 == self.id5 or self.mp8 == self.id6 or self.mp8 == self.id7 or self.mp8 == self.id8 or self.mp8 == self.id9 then
    world.damageTileArea(self.hitPosition8, self.area, "foreground", self.hitPosition8, "blockish", self.damage, 99)
  end
  if self.mp9 == self.id1  or self.mp9 == self.id2 or self.mp9 == self.id3 or self.mp9 == self.id4 or self.mp9 == self.id5 or self.mp9 == self.id6 or self.mp9 == self.id7 or self.mp9 == self.id8 or self.mp9 == self.id9 then
    world.damageTileArea(self.hitPosition9, self.area, "foreground", self.hitPosition9, "blockish", self.damage, 99)
  end
		
  end
end

function ShovelDig:mineBackground()
 --mp; Material Position
  self.mp1 = world.material(self.hitPosition1, "background")
  self.mp2 = world.material(self.hitPosition2, "background")
  self.mp3 = world.material(self.hitPosition3, "background")
  self.mp4 = world.material(self.hitPosition4, "background")
  self.mp5 = world.material(self.hitPosition5, "background")
  self.mp6 = world.material(self.hitPosition6, "background")
  self.mp7 = world.material(self.hitPosition7, "background")
  self.mp8 = world.material(self.hitPosition8, "background")
  self.mp9 = world.material(self.hitPosition9, "background")
	
  if self.fireMode == "alt" then
  if self.mp1 == self.id1  or self.mp1 == self.id2 or self.mp1 == self.id3 or self.mp1 == self.id4 or self.mp1 == self.id5 or self.mp1 == self.id6 or self.mp1 == self.id7 or self.mp1 == self.id8 or self.mp1 == self.id9 then
    world.damageTileArea(self.hitPosition1, self.area, "background", self.hitPosition1, "blockish", self.damage, 99)
  end
  if self.mp2 == self.id1  or self.mp2 == self.id2 or self.mp2 == self.id3 or self.mp2 == self.id4 or self.mp2 == self.id5 or self.mp2 == self.id6 or self.mp2 == self.id7 or self.mp2 == self.id8 or self.mp2 == self.id9 then
    world.damageTileArea(self.hitPosition2, self.area, "background", self.hitPosition2, "blockish", self.damage, 99)
  end
  if self.mp3 == self.id1  or self.mp3 == self.id2 or self.mp3 == self.id3 or self.mp3 == self.id4 or self.mp3 == self.id5 or self.mp3 == self.id6 or self.mp3 == self.id7 or self.mp3 == self.id8 or self.mp3 == self.id9 then
    world.damageTileArea(self.hitPosition3, self.area, "background", self.hitPosition3, "blockish", self.damage, 99)
  end
  if self.mp4 == self.id1  or self.mp4 == self.id2 or self.mp4 == self.id3 or self.mp4 == self.id4 or self.mp4 == self.id5 or self.mp4 == self.id6 or self.mp4 == self.id7 or self.mp4 == self.id8 or self.mp4 == self.id9 then
    world.damageTileArea(self.hitPosition4, self.area, "background", self.hitPosition4, "blockish", self.damage, 99)
  end
  if self.mp5 == self.id1  or self.mp5 == self.id2 or self.mp5 == self.id3 or self.mp5 == self.id4 or self.mp5 == self.id5 or self.mp5 == self.id6 or self.mp5 == self.id7 or self.mp5 == self.id8 or self.mp5 == self.id9 then
    world.damageTileArea(self.hitPosition5, self.area, "background", self.hitPosition5, "blockish", self.damage, 99)
  end
  if self.mp6 == self.id1  or self.mp6 == self.id2 or self.mp6 == self.id3 or self.mp6 == self.id4 or self.mp6 == self.id5 or self.mp6 == self.id6 or self.mp6 == self.id7 or self.mp6 == self.id8 or self.mp6 == self.id9 then
    world.damageTileArea(self.hitPosition6, self.area, "background", self.hitPosition6, "blockish", self.damage, 99)
  end
  if self.mp7 == self.id1  or self.mp7 == self.id2 or self.mp7 == self.id3 or self.mp7 == self.id4 or self.mp7 == self.id5 or self.mp7 == self.id6 or self.mp7 == self.id7 or self.mp7 == self.id8 or self.mp7 == self.id9 then
    world.damageTileArea(self.hitPosition7, self.area, "background", self.hitPosition7, "blockish", self.damage, 99)
  end
  if self.mp8 == self.id1  or self.mp8 == self.id2 or self.mp8 == self.id3 or self.mp8 == self.id4 or self.mp8 == self.id5 or self.mp8 == self.id6 or self.mp8 == self.id7 or self.mp8 == self.id8 or self.mp8 == self.id9 then
    world.damageTileArea(self.hitPosition8, self.area, "background", self.hitPosition8, "blockish", self.damage, 99)
  end
  if self.mp9 == self.id1  or self.mp9 == self.id2 or self.mp9 == self.id3 or self.mp9 == self.id4 or self.mp9 == self.id5 or self.mp9 == self.id6 or self.mp9 == self.id7 or self.mp9 == self.id8 or self.mp9 == self.id9 then
    world.damageTileArea(self.hitPosition9, self.area, "background", self.hitPosition9, "blockish", self.damage, 99)
  end

  end
end
