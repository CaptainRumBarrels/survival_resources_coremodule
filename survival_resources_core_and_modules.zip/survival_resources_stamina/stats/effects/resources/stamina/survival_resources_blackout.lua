require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.energyBarSize = root.imageSize("/scripts/survival_resources_blackout.png")
  self.energyBarFrameOffset = {0, 0}
  self.energyBarOffset = {self.energyBarFrameOffset[1] - self.energyBarSize[1] / 16, self.energyBarFrameOffset[2] - self.energyBarSize[2] / 16}
  self.fainted = false
end

function update()

  --status.addEphemeralEffect("colorblue", 0.1)
  localAnimator.clearDrawables()
  localAnimator.addDrawable({
    image = "/scripts/survival_resources_blackout.png",
    fullbright = true,
	position = self.energyBarOffset,
	centered = false,
	transformation = {
      {2, 0, -120},
      {0, 2.1, -75},
      {0, 0, 1}
    }
  }, "overlay")

end


function uninit()
  
end