require "/scripts/vec2.lua"
require "/scripts/util.lua"
require "/scripts/activeitem/stances.lua"

function init()
  self.fireOffset = config.getParameter("fireOffset")
  updateAim()
  harvestwater()
  self.harvestInterval = 0
  self.harvestTime = 0.75
  self.drinkInterval = 0
  self.drinkTime = 1.0
end

function activate(fireMode, shiftHeld)
  
end

function update(dt, fireMode, shiftHeld)
  if fireMode == "primary" or fireMode == "alt" then
	if not mcontroller.liquidMovement() and player.hasItem("liquidwater") then
	  consumeWater(dt)
	end
  else
	updateAim()
	harvestwater(dt)
  end
	
  self.harvestInterval = math.max(self.harvestInterval - dt, 0)
  self.drinkInterval = math.max(self.drinkInterval - dt, 0)
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffset[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(self.aimAngle)
  activeItem.setFacingDirection(self.aimDirection)
end

function harvestwater(dt)
  local entityPosition = world.entityPosition(activeItem.ownerEntityId())
  self.cursorPosition = activeItem.ownerAimPosition()
  local distance = vec2.mag(world.distance(entityPosition, self.cursorPosition))
  if distance <= 5 then
    if world.liquidAt(self.cursorPosition) and self.harvestInterval == 0 then 
	  world.destroyLiquid(self.cursorPosition)
	  player.giveItem("liquidwater")
	  self.harvestInterval = self.harvestTime
    end
  end
end

function consumeWater(dt)
  activeItem.setArmAngle(0.4)
  activeItem.emote("oh")
  if self.drinkInterval == 0 then
	player.consumeItem("liquidwater")
	self.drinkInterval = self.drinkTime
	status.giveResource("health", 2)
	status.giveResource("hunger", 0.25)
	status.giveResource("survival_resources_resourceBiowaste2", 1)
  end
end

function uninit()
  
end
