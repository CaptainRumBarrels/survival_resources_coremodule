function init()
  --animator.setParticleEmitterOffsetRegion("drips", mcontroller.boundBox())
  --animator.setParticleEmitterActive("drips", true)
  --effect.setParentDirectives("fade=505000=0.6")
  effect.addStatModifierGroup({
    {stat = "jumpModifier", amount = -0.15}
  })
end

function update(dt)
  mcontroller.controlModifiers({
      speedModifier = 0.9,
      airJumpModifier = 0.95
    })
end

function onExpire()

end

function uninit()
  
end
