function init()
  self.intermittentBiowasteSoundThreshold = 100
  self.biowasteSoundTimer = 2.0
  self.maxSolidWasteAmount = 15
  self.minSolidWasteAmount = 1
  self.stage1 = false
  self.stage2 = false
  self.stageFinal = false
  self.toilet1Sound = false
end

function update(dt)
--if (healthFactor < self.intermittentDamageSoundThreshold) then
--local healthFactor = 1
	
  local maxInterval = 11
  local minInterval = 1
  if status.resourcePercentage("survival_resources_resourceBiowaste") > 0.01 or status.resourcePercentage("survival_resources_resourceBiowaste2") > 0.01 then
    self.biowasteSoundTimer = self.biowasteSoundTimer - script.updateDt()

    if (self.biowasteSoundTimer <= 0) then
      self.biowasteSoundTimer = math.random(minInterval, maxInterval) --* randomMax;
			
	  if not self.stage1 then
	    self.stage1 = true
	  elseif self.stage1 and not self.stage2 then
		self.stage1 = true
		self.stage2 = true
	  elseif self.stage1 and self.stage2 then
		self.stage1 = false
		self.stage2 = false
		self.stageFinal = true
	  end				
      if self.stage2 or self.stageFinal then
        solidWaste()
      end	
    end
		
	if self.stage1 or self.stage2 then
	  liquidWaste()
	end
		
	if self.stageFinal and self.toilet1Sound then
	  animator.stopAllSounds("toilet1")
	  self.toilet1Sound = false
	end
  else
	animator.stopAllSounds("toilet1")
	animator.stopAllSounds("toilet2")
  end
--end
  --a random time that changes depending on how damaged the vehicle is.
  --local randomMax = (healthFactor * self.maxDamageSoundInterval) + ((1.0 - healthFactor) * self.minDamageSoundInterval)
  --status.overConsumeResource("survival_resources_resourceBiowaste", 0.1)
end

function liquidWaste()
  if not self.toilet1Sound then
    animator.playSound("toilet1")
	self.toilet1Sound = true
  end
  status.overConsumeResource("survival_resources_resourceBiowaste2", 0.05)
end

function solidWaste()
  animator.playSound("toilet2")
  self.producedSolidWasteAmount = math.random(self.minSolidWasteAmount, self.maxSolidWasteAmount)
  status.overConsumeResource("survival_resources_resourceBiowaste", self.producedSolidWasteAmount)
end

function uninit()
  animator.stopAllSounds("toilet1")
end
