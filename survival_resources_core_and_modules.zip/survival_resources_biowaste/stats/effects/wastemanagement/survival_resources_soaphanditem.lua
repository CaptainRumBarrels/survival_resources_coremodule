function init()
  --script.setUpdateDelta(0) -- 60 is 1 second. Updates every frame. 6 frames will give 10 points over 1 second. 12, 10 points 2 seconds, 24, 4 seconds
end

function update(dt)
  status.removeEphemeralEffect("survival_resources_soiled1")
  status.removeEphemeralEffect("survival_resources_soiled2")
end

function uninit()
  
end