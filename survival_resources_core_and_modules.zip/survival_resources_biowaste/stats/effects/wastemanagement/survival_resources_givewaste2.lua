require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.givewaste = false
end

function update(dt)
  if not self.givewaste then
	self.givewaste = true
	status.giveResource("survival_resources_resourceBiowaste2", 15)
	effect.expire()	
  end
end

function uninit()
  self.givewaste = false
end