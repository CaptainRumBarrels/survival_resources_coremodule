require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()

end

function update(dt)
  local xVelocity = 0.0 * mcontroller.facingDirection()
  local projectileParameters = {}
  if mcontroller.crouching() then
    world.spawnProjectile("survival_resources_biowaste2", vec2.add(entity.position(), {0.0, -1.8}), entity.id(), {xVelocity,-0.1}, false, projectileParameters)
  elseif not mcontroller.crouching() then
	world.spawnProjectile("survival_resources_biowaste2", vec2.add(entity.position(), {0.0, -1.25}), entity.id(), {xVelocity,-0.1}, false, projectileParameters)
  end
  status.overConsumeResource("survival_resources_resourceBiowaste2", 0.15)
end

function uninit()

end