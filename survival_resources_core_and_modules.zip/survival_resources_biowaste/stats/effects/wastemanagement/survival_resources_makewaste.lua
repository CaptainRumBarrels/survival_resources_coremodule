require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.projectile = false
end

function update(dt)
  if not self.projectile then
	self.projectile = true
    local projectileParameters = {}
    world.spawnProjectile("survival_resources_biowaste", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {0.0,-1.0}, false, projectileParameters)
	--world.placeMaterial(entity.position(), "foreground", "sewage", 5, true)
  end
  if self.projectile then
	effect.expire()	
  end
end

function uninit()

end