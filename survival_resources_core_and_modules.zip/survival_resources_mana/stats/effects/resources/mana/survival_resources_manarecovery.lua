function init()
  
end

function update(dt)
  if status.resourcePercentage("survival_resources_resourceMana") < 1.0 then
    status.setResource("survival_resources_resourceMana", status.resource("survival_resources_resourceMana") + 0.025)
  end
end

function uninit()
  
end
