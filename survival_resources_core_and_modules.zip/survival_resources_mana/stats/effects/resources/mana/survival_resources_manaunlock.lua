function init()
  
end

function update()
  if status.resourcePercentage("survival_resources_resourceManaUnlock") == 0 then
    animator.playSound("activate")
	status.setResourcePercentage("survival_resources_resourceManaUnlock", 1.0)
  end
end

function uninit()
  
end