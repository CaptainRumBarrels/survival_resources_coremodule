function init()
  reset()
  script.setUpdateDelta(10)
  self.movementDelay = 0
end

function update(dt)
  self.movementDelay = math.max(0, self.movementDelay - dt)
  
  if (self.movementDelay <= 0) then
    fade()
  end
	
  if self.stage20 then
    status.overConsumeResource("survival_resources_resourceMana", 0.75)
	status.addEphemeralEffect("survival_resources_staminabuff4b", 1.0)
  end

  if mcontroller.walking() or mcontroller.running() or mcontroller.falling() or mcontroller.jumping() or mcontroller.liquidMovement() then
    self.movementDelay = 3.5
    reset()	
  end  
	
end
	
function fade()
  if not self.stage1 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.95 * 255)))
	self.stage1 = true
  elseif self.stage1 and not self.stage2 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.90 * 255)))
	self.stage2 = true		
  elseif self.stage2 and not self.stage3 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.85 * 255)))
	self.stage3 = true
  elseif self.stage3 and not self.stage4 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.80 * 255)))
	self.stage4 = true	
  elseif self.stage4 and not self.stage5 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.75 * 255)))
	self.stage5 = true	
  elseif self.stage5 and not self.stage6 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.70 * 255)))
	self.stage6 = true	
  elseif self.stage6 and not self.stage7 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.65 * 255)))
	self.stage7 = true	
  elseif self.stage7 and not self.stage8 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.60 * 255)))
	self.stage8 = true	
  elseif self.stage8 and not self.stage9 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.55 * 255)))
	self.stage9 = true	
  elseif self.stage9 and not self.stage10 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.50 * 255)))
	self.stage10 = true
  elseif self.stage10 and not self.stage11 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.45 * 255)))
	self.stage11 = true		
  elseif self.stage11 and not self.stage12 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.40 * 255)))
	self.stage12 = true
  elseif self.stage12 and not self.stage13 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.35 * 255)))
	self.stage13 = true	
  elseif self.stage13 and not self.stage14 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.30 * 255)))
	self.stage14 = true	
  elseif self.stage14 and not self.stage15 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.25 * 255)))
	self.stage15 = true	
  elseif self.stage15 and not self.stage16 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.20 * 255)))
	self.stage16 = true	
  elseif self.stage16 and not self.stage17 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.15 * 255)))
	self.stage17 = true	
  elseif self.stage17 and not self.stage18 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.10 * 255)))
	self.stage18 = true	
  elseif self.stage18 and not self.stage19 then
    effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.05 * 255)))
	self.stage19 = true
  elseif self.stage19 and not self.stage20 then
	effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(0.0 * 255)))
	self.stage20 = true
  end		
end

function reset()
  effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(1.0 * 255)))
	
  self.stage1 = false
  self.stage2 = false
  self.stage3 = false
  self.stage4 = false
  self.stage5 = false
  self.stage6 = false
  self.stage7 = false
  self.stage8 = false
  self.stage9 = false
  self.stage10 = false
  self.stage11 = false
  self.stage12 = false
  self.stage13 = false
  self.stage14 = false
  self.stage15 = false
  self.stage16 = false
  self.stage17 = false
  self.stage18 = false
  self.stage19 = false
  self.stage20 = false	
end

function uninit()
  effect.setParentDirectives(string.format("?multiply=ffffff%02x", math.floor(1.0 * 255)))
end
