require "/scripts/util.lua"
require "/scripts/status.lua"

function init()
  animator.setParticleEmitterActive("sparks", true)
  effect.setParentDirectives("fade=CC5555=0.25")

  script.setUpdateDelta(5)

  self.triggerDamageThreshold = config.getParameter("triggerDamageThreshold")

  self.timeUntilActive = config.getParameter("activateDelay")
  self.projectileSpawned = false
end

function update(dt)
  if (status.resourcePercentage("health") <= 0) and not self.projectileSpawned then
	trigger()
	self.projectileSpawned = true
  end
end

function uninit()

end

function trigger()
  status.applySelfDamageRequest({
      damageType = "IgnoresDef",
      damage = config.getParameter("explosionDamageAmount"),
      damageSourceKind = "default",
      sourceEntityId = entity.id()
    })
  world.spawnProjectile(
      "zbomb",
      mcontroller.position(),
      entity.id(),
      {0, 0},
      true,
      {}
    )
  animator.burstParticleEmitter("sparks")
  animator.setParticleEmitterActive("sparks", false)
  animator.setLightActive("glow", false)
  self.timeUntilExpire = config.getParameter("deactivateDelay")
end
