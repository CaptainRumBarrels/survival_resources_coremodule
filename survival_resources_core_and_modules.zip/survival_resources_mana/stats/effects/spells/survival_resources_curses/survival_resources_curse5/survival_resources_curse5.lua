require "/scripts/util.lua"
require "/scripts/status.lua"

function init()
  animator.setParticleEmitterActive("sparks", true)
  effect.setParentDirectives("fade=CC5555=0.25")
end

function update(dt)
  projectile()
end

function uninit()

end

function projectile()
  world.spawnProjectile(
      "survival_resources_curse5status",
      mcontroller.position(),
      entity.id(),
      {0, 0},
      true,
      {}
    )
  animator.burstParticleEmitter("sparks")
  animator.setParticleEmitterActive("sparks", false)
  animator.setLightActive("glow", false)
  self.timeUntilExpire = config.getParameter("deactivateDelay")
end
