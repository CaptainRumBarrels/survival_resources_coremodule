function init()
  self.fallSpeedLimit = -25
end

function update(dt)
  if self.fallSpeedLimit > mcontroller.yVelocity() and mcontroller.liquidMovement() then
	mcontroller.controlApproachYVelocity(-25 , 500)
  end
  if mcontroller.liquidMovement() then
    mcontroller.controlParameters({
	  liquidFriction = 0, --various ways to negate normal movement parameters
	  liquidImpedance = 0,
	  liquidForce = 150
    })
  end
  
  status.setResourcePercentage("breath", 1.0)
	-- function disabled. Player approaching very high velocity and taking hundreds of points of damage when x velocity bonus is in effect.
  --if mcontroller.running() or mcontroller.walking() then
  	--mcontroller.controlApproachXVelocity((20 * mcontroller.facingDirection()), 50)
  --end
end

function uninit()
  
end
