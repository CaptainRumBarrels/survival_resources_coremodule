survival_resources_staminabuff4 = WeaponAbility:new()

function survival_resources_staminabuff4:init()
  self.coolDown = 0
  self.abilityCooldown = 3
  self.resourceConsumptionTimer = 0
  self.active = false
end

function survival_resources_staminabuff4:update(dt, fireMode, shiftHeld)
  WeaponAbility.update(self, dt, fireMode, shiftHeld)	
  self.coolDown = math.max(0, self.coolDown - dt)
	
  if self.fireMode == "alt" and self.lastFireMode ~= "alt" then
	if not self.active and (self.coolDown <= 0) then
	  self.active = true
	elseif self.active then
	  self.active = false
	  self.coolDown = self.abilityCooldown
	end
  end
  if self.fireMode == "primary" and self.lastFireMode ~= "primary" then
    status.removeEphemeralEffect("survival_resources_staminabuff4")
  end
  self.lastFireMode = fireMode
	
  if self.active then
	status.addEphemeralEffect("survival_resources_staminabuff4", 0.1)
  elseif not self.active then
	status.removeEphemeralEffect("survival_resources_staminabuff4")
  end
end

function survival_resources_staminabuff4:uninit()
  
end
