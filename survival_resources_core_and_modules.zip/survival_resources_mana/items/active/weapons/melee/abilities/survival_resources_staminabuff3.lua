survival_resources_staminabuff3 = WeaponAbility:new()

function survival_resources_staminabuff3:init()
  self.coolDown = 0
  self.abilityCooldown = 3
  self.resourceConsumptionTimer = 0
  self.active = false
end

function survival_resources_staminabuff3:update(dt, fireMode, shiftHeld)
  WeaponAbility.update(self, dt, fireMode, shiftHeld)	
  self.coolDown = math.max(0, self.coolDown - dt)
	
  if self.fireMode == "alt" and self.lastFireMode ~= "alt" then
	if not self.active and (self.coolDown <= 0) then
	  self.active = true
	elseif self.active then
	  self.active = false
	  self.coolDown = self.abilityCooldown
	end
  end
  self.lastFireMode = fireMode
	
  if self.active then
	--status.overConsumeResource("survival_resources_resourceStamina", 0.0075)
	status.overConsumeResource("survival_resources_resourceMana", 0.025)
	status.addEphemeralEffect("thorns", 5)
  elseif not self.active then
	status.removeEphemeralEffect("thorns")
  end
end

function survival_resources_staminabuff3:uninit()
  
end
