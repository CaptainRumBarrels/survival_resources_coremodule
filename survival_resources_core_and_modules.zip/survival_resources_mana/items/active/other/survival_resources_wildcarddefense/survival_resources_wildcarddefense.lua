require "/scripts/vec2.lua"
require "/scripts/util.lua"
require "/scripts/activeitem/stances.lua"

function init()
  self.fireOffset = config.getParameter("fireOffset")
  animator.playSound("open")
  updateAim()
  self.random = false
  self.altFiremodeActive = false
  self.weaponIndex = 1
  self.manaCost = 0
  self.spellCooldown = 0
  self.soundTimer = 0
  self.soundRepeat = 5.0
end

function activate(fireMode, shiftHeld)
  if fireMode == "alt" and not self.random then
    self.random = true
  elseif fireMode == "alt" and self.random then
    self.random = false	
  end
end

function update(dt, fireMode, shiftHeld)
  self.spellCooldown = math.max(self.spellCooldown - dt, 0)
	
  self.soundTimer = math.max(self.soundTimer - dt, 0)
	
  activeItem.setHoldingItem(false)
  local min = 1
  local max = 51
  local projectileParameters = {
    power = 4,
    powerMultiplier = 1,
	speed = 65,
	timeToLive = 2.5
  }
	
  if fireMode == "primary" and self.spellCooldown == 0 then
		
    if self.soundTimer == 0 then
	  self.soundTimer = self.soundRepeat
	  animator.playSound("fire")
	end
		
    world.spawnProjectile(self.projectile, vec2.add(entity.position(), {0.0, 0.0}), entity.id(), aimVector(), false, projectileParameters)
	if not self.random then
	self.spellCooldown = 0.15
	self.weaponIndex = self.weaponIndex + 1
	elseif self.random then
	  self.spellCooldown = 0.15
	  self.weaponIndex = math.random(min, max)	
	end
	status.consumeResource("survival_resources_resourceMana", 2)
  end
  if self.weaponIndex > max then
    self.weaponIndex = 1
  end
  
  updateAim()
  updateProjectile()
  --animator.stopAllSounds("fire")
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffset[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(self.aimAngle)
  activeItem.setFacingDirection(self.aimDirection)
end

function aimVector()
  local aimVector = vec2.rotate({1, 0}, self.aimAngle + sb.nrand(config.getParameter("inaccuracy", 0), 0))
  aimVector[1] = aimVector[1] * self.aimDirection
  return aimVector
end

function uninit()
  
end

function updateProjectile()
  --if self.weaponIndex ==  then self.projectile = "" end
  if self.weaponIndex == 1 then self.projectile = "flare" end
  if self.weaponIndex == 2 then self.projectile = "throwingknife" end
  if self.weaponIndex == 3 then self.projectile = "penguintankround" end
  if self.weaponIndex == 4 then self.projectile = "fireswirl" end
  if self.weaponIndex == 5 then self.projectile = "pig" end
  if self.weaponIndex == 6 then self.projectile = "throwinggnome" end
  if self.weaponIndex == 7 then self.projectile = "money" end
  if self.weaponIndex == 8 then self.projectile = "throwingspear" end
  if self.weaponIndex == 9 then self.projectile = "tarball" end
  if self.weaponIndex == 10 then self.projectile = "giganticsnowball" end
  if self.weaponIndex == 11 then self.projectile = "hivebomb" end
  if self.weaponIndex == 12 then self.projectile = "throwingaxe" end
  if self.weaponIndex == 13 then self.projectile = "acidspit" end
  if self.weaponIndex == 14 then self.projectile = "throwingbones" end
  if self.weaponIndex == 15 then self.projectile = "fireworkblue" end
  if self.weaponIndex == 16 then self.projectile = "watergun" end
  if self.weaponIndex == 17 then self.projectile = "gravitymine" end
  if self.weaponIndex == 18 then self.projectile = "carrot" end
  if self.weaponIndex == 19 then self.projectile = "rainbow" end
  if self.weaponIndex == 20 then self.projectile = "junktire" end
  if self.weaponIndex == 21 then self.projectile = "mudball" end
  if self.weaponIndex == 22 then self.projectile = "miniwobbleshot" end
  if self.weaponIndex == 23 then self.projectile = "spaceplasma" end
  if self.weaponIndex == 24 then self.projectile = "ironarrow" end
  if self.weaponIndex == 25 then self.projectile = "biolumcritters" end
  if self.weaponIndex == 26 then self.projectile = "cropshipment" end
  if self.weaponIndex == 27 then self.projectile = "mechhomingmissile" end
  if self.weaponIndex == 28 then self.projectile = "heatbeam" end
  if self.weaponIndex == 29 then self.projectile = "teslabolt" end
  if self.weaponIndex == 30 then self.projectile = "boomerang" end
  if self.weaponIndex == 31 then self.projectile = "icespinswoosh" end
  if self.weaponIndex == 32 then self.projectile = "pushzone" end
  if self.weaponIndex == 33 then self.projectile = "moontantgoop" end
  if self.weaponIndex == 34 then self.projectile = "balllightning" end
  if self.weaponIndex == 35 then self.projectile = "stunzone" end
  if self.weaponIndex == 36 then self.projectile = "astraltearstart" end
  if self.weaponIndex == 37 then self.projectile = "lightball" end
  if self.weaponIndex == 38 then self.projectile = "cellblast" end
  if self.weaponIndex == 39 then self.projectile = "spikefistrocket" end
  if self.weaponIndex == 40 then self.projectile = "beetle" end
  if self.weaponIndex == 41 then self.projectile = "clustergoo" end
  if self.weaponIndex == 42 then self.projectile = "bubbles" end
  if self.weaponIndex == 43 then self.projectile = "fish1" end
  if self.weaponIndex == 44 then self.projectile = "gooroller" end
  if self.weaponIndex == 45 then self.projectile = "slowzone" end
  if self.weaponIndex == 46 then self.projectile = "meteor" end
  if self.weaponIndex == 47 then self.projectile = "lightarrow" end
  if self.weaponIndex == 48 then self.projectile = "razorleaf" end
  if self.weaponIndex == 49 then self.projectile = "spinslash" end
  if self.weaponIndex == 50 then self.projectile = "sonicwave" end
  if self.weaponIndex == 51 then self.projectile = "junksatellite2" end
end