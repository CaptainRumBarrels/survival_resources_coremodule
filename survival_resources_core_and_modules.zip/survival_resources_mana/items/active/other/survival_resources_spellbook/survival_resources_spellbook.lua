require "/scripts/vec2.lua"
require "/scripts/util.lua"
require "/scripts/activeitem/stances.lua"

function init()
  self.fireOffset = config.getParameter("fireOffset")
  animator.setAnimationState("book", "spellSlot1")
  updateAim()
  self.spellSlot1 = true
  self.spellSlot2 = false
  self.spellSlot3 = false
  self.spellSlot4 = false
  self.spellSlot5 = false

  self.altFiremodeActive = false

  self.manaCost = 0
  self.spellCooldown = 0
  self.spellDuration = 0
  self.spellRecharge = 3.5 -- Cooldown = Duration + Recharge. i.e. the length of time spell is active plus a predetermined lag phase. In this case 5s
end

function activate(fireMode, shiftHeld)
  if fireMode == "alt" then
    if self.spellSlot1 then -- change to 2
      self.spellSlot1 = false
	  self.spellSlot2 = true
	  self.spellSlot3 = false
	  self.spellSlot4 = false
	  self.spellSlot5 = false
	  --status.addEphemeralEffect("colorblue", 0.5)
	  animator.setAnimationState("book", "spellSlot2")
	  animator.playSound("open")
    elseif self.spellSlot2 then -- change to 3 etc.
      self.spellSlot1 = false
	  self.spellSlot2 = false
	  self.spellSlot3 = true
	  self.spellSlot4 = false
	  self.spellSlot5 = false
	  --status.addEphemeralEffect("colorred", 0.5)
	  animator.setAnimationState("book", "spellSlot3")
	elseif self.spellSlot3 then
      self.spellSlot1 = false
	  self.spellSlot2 = false
	  self.spellSlot3 = false
	  self.spellSlot4 = true
	  self.spellSlot5 = false
	  --status.addEphemeralEffect("colorgreen", 0.5)
	  animator.setAnimationState("book", "spellSlot4")
	  animator.playSound("open")
	elseif self.spellSlot4 then
      self.spellSlot1 = false
	  self.spellSlot2 = false
	  self.spellSlot3 = false
	  self.spellSlot4 = false
	  self.spellSlot5 = true
	  --status.addEphemeralEffect("colorpurple", 0.5)
	  animator.setAnimationState("book", "spellSlot5")
	  animator.playSound("open")
	elseif self.spellSlot5 then -- reset loop back to 1
      self.spellSlot1 = true
	  self.spellSlot2 = false
	  self.spellSlot3 = false
	  self.spellSlot4 = false
	  self.spellSlot5 = false
	  --status.addEphemeralEffect("glow", 0.5)
	  animator.setAnimationState("book", "spellSlot1")
	  animator.playSound("open")
	end
  end
end

function update(dt, fireMode, shiftHeld)
  self.spellCooldown = math.max(self.spellCooldown - dt, 0)
	
  if self.spellSlot1 then -- change to 2		
	self.spellDuration = 0.5
    self.costOfSpell1 = 10
  elseif self.spellSlot2 then -- change to 3 etc.
	self.spellDuration = 20
	self.costOfSpell2 = 30
  elseif self.spellSlot3 then
	self.spellDuration = 60
	self.costOfSpell3 = 15
  elseif self.spellSlot4 then
	self.spellDuration = 60
	self.costOfSpell4 = 5
  elseif self.spellSlot5 then -- reset loop back to 1
	self.spellDuration = 120
	self.costOfSpell5 = 5
  end
	
  if fireMode == "primary" and self.spellCooldown == 0 then
	if self.spellSlot1 and (status.resource("survival_resources_resourceMana") >= self.costOfSpell1) then
	  mcontroller.setPosition(activeItem.ownerAimPosition())
	  status.addEphemeralEffect("blink", self.spellDuration)
	  --status.addEphemeralEffect("nofalldamage", self.spellDuration)
	  self.spellCooldown = self.spellRecharge --+ self.spellDuration
	  status.consumeResource("survival_resources_resourceMana", self.costOfSpell1)
	end
	if self.spellSlot2 and (status.resource("survival_resources_resourceMana") >= self.costOfSpell2) then
	  status.addEphemeralEffect("invisible", self.spellDuration)
	  status.addEphemeralEffect("invulnerable", self.spellDuration)
	  self.spellCooldown = self.spellRecharge --+ self.spellDuration
	  status.consumeResource("survival_resources_resourceMana", self.costOfSpell2)
	end
	if self.spellSlot3 and (status.resource("survival_resources_resourceMana") >= self.costOfSpell2) then
	  status.addEphemeralEffect("nova", self.spellDuration)
	  self.spellCooldown = self.spellRecharge --+ self.spellDuration
	  status.consumeResource("survival_resources_resourceMana", self.costOfSpell3)
	end
	if self.spellSlot4 and (status.resource("survival_resources_resourceMana") >= self.costOfSpell2) then
	  status.addEphemeralEffect("glow", self.spellDuration)
	  self.spellCooldown = self.spellRecharge --+ self.spellDuration
	  status.consumeResource("survival_resources_resourceMana", self.costOfSpell4)
	end
	if self.spellSlot5 and (status.resource("survival_resources_resourceMana") >= self.costOfSpell2) then
	  status.addEphemeralEffect("colorblue", self.spellDuration)
	  status.addEphemeralEffect("survival_resources_swimboost", self.spellDuration)
	  self.spellCooldown = self.spellRecharge --+ self.spellDuration
	  status.consumeResource("survival_resources_resourceMana", self.costOfSpell5)
	end
	--status.overConsumeResource("survival_resources_resourceMana", 0.06)
  end
  
  updateAim()
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffset[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(self.aimAngle)
  activeItem.setFacingDirection(self.aimDirection)
end

function uninit()
  
end
