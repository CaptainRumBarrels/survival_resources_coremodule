require "/scripts/vec2.lua"
require "/scripts/util.lua"
require "/scripts/activeitem/stances.lua"

function init()
  self.fireOffset = config.getParameter("fireOffset")
  updateAim()
end

function activate(fireMode, shiftHeld)
  
end

function update(dt, fireMode, shiftHeld)
  if fireMode == "primary" or fireMode == "alt" then
	status.giveResource("health", 0.25)
	status.overConsumeResource("survival_resources_resourceMana", 0.06)
  else
	updateAim()
  end
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffset[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(self.aimAngle)
  activeItem.setFacingDirection(self.aimDirection)
end

function uninit()
  
end
