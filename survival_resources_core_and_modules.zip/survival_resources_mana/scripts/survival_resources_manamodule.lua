require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  initializeResource()
end

function update(dt)
  adminDefaults()
  resourceMana()
  racialBonus()
	
  status.setResourcePercentage("survival_resources_resourceManaactive", 1.0)	
end

function adminDefaults()
  if player.isAdmin() then
    status.setResourcePercentage("survival_resources_resourceMana", 1.0)	
  end
end

function initializeResource()
  if status.resourcePercentage("interfaceResourceLogic2") == 1.0 then
  	status.setResourcePercentage("survival_resources_resourceMana", 1.0)
	status.setResourcePercentage("interfaceResourceLogic2", 0.0)
	
	--if (status.resourcePercentage("survival_resources_resourceManaUnlock") <= 0.0) then
      status.setResource("survival_resources_resourceManaUnlock", 1)
    --end
    --if (status.resourcePercentage("survival_resources_resourceMana") == 1.0) then
      status.setResource("survival_resources_resourceManaUnlock2", 1)
    --end
  end		
end

function resourceMana()
  if (status.resourcePercentage("survival_resources_resourceManaUnlock") == 1.0) then
    if status.resourceLocked("survival_resources_resourceMana") then
      if (status.resourcePercentage("survival_resources_resourceMana") <= 0.5) then
	    status.giveResource("survival_resources_resourceMana", 0.03)
      end
    end
  end
	
  if (status.resourcePercentage("survival_resources_resourceManaUnlock2") == 1.0) then
    if status.resourceLocked("survival_resources_resourceMana") then 
      status.giveResource("survival_resources_resourceMana", 0.015)
    end
  end
	
  if (status.resourcePercentage("survival_resources_resourceMana") <= 0.0) then
    status.setResourceLocked("survival_resources_resourceMana", true)
  elseif (status.resourcePercentage("survival_resources_resourceMana") >= 1.0) then
	status.setResourceLocked("survival_resources_resourceMana", false)
  end
end

function racialBonus()
  if world.entitySpecies(player.id()) == "avian" then
    if (status.resourcePercentage("survival_resources_resourceMana") <= 0.5) and mcontroller.groundMovement() and not mcontroller.running() and not mcontroller.walking() then
	  status.giveResource("survival_resources_resourceMana", 0.01)
	end  	
  end
end

function uninit()
	
end