require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.recoilTime = 0
end

function update(dt)	
  mcontroller.setXVelocity(0)
  self.recoilTime = math.max(self.recoilTime - dt, 0)	
  if mcontroller.isColliding() then
	recoil()
	self.recoilTime = 0.1
  end
end

function recoil()
 if self.recoilTime > 0 then
   mcontroller.setYVelocity(50)
 end
end

function uninit()
	
end