function init()
  self.pageNumber = 1
  self.pageTotal = 10
end

function uninit()
  status.setResource("interfaceResourceLogic4", 0)
end

function update(dt)
  if status.resourcePercentage("interfaceResourceLogic4") == 0 then
	pane.dismiss()	
  end
	
  changeContentVisibility()
  checkPageNumberRange()
  updateTabs()
end

function buttonPreviousPage()
  self.pageNumber = self.pageNumber - 1
end

function buttonNextPage()
  self.pageNumber = self.pageNumber + 1
end

function chapterGroupCallback()
  local selectedTab = widget.getSelectedOption("chapterRadioGroup")
	
  if selectedTab == 0 then self.pageNumber = 1 end
  if selectedTab == 1 then self.pageNumber = 2 end
  if selectedTab == 2 then self.pageNumber = 3 end
  if selectedTab == 5 then self.pageNumber = 10 end
  
  --This function checks the page number and sets the tab to be highlighted when you enter the page range from outside the numbers.
  --but sets the page number to the beginning of the section if we click on a tab and we are outside the page range.

	
  if selectedTab == 3 and self.pageNumber < 4 or selectedTab == 3 and self.pageNumber > 5 then self.pageNumber = 4
  elseif selectedTab == 3 and self.pageNumber >= 4 and self.pageNumber <= 5 then self.pageNumber = self.pageNumber end
	
  if selectedTab == 4 and self.pageNumber < 6 or selectedTab == 4 and self.pageNumber > 9 then self.pageNumber = 6
  elseif selectedTab == 4 and self.pageNumber >= 6 and self.pageNumber <= 9 then self.pageNumber = self.pageNumber end
	
end

function updateTabs()
  if self.pageNumber == 1 then widget.setSelectedOption("chapterRadioGroup", 0) end
  if self.pageNumber == 2 then widget.setSelectedOption("chapterRadioGroup", 1) end
  if self.pageNumber == 3 then widget.setSelectedOption("chapterRadioGroup", 2) end
  if self.pageNumber == 4 or self.pageNumber == 5 then widget.setSelectedOption("chapterRadioGroup", 3) end
  if self.pageNumber == 6 or self.pageNumber == 9 then widget.setSelectedOption("chapterRadioGroup", 4) end
  if self.pageNumber == 10 then widget.setSelectedOption("chapterRadioGroup", 5) end
	
  --if self.pageNumber == 11 then widget.setSelectedOption("chapterRadioGroup", 4) end
	
  --if self.pageNumber == 12 or self.pageNumber == 13 then widget.setSelectedOption("chapterRadioGroup", 5) end
	
  --if self.pageNumber == 14 then widget.setSelectedOption("chapterRadioGroup", 6) end
	
end

function checkPageNumberRange()
  if self.pageNumber <= 1 then
    self.pageNumber = 1
  elseif self.pageNumber >= self.pageTotal then
	self.pageNumber = self.pageTotal
  else
    self.pageNumber = self.pageNumber
  end
	
  widget.setText("pageNumberLabelCurrent", math.floor(string.format("%s", self.pageNumber)))
end

function changeContentVisibility()
  --Misc
  widget.setVisible("pageDottedLinesLeft", false)
  widget.setVisible("pageDottedLinesRight", false)

  page1()
  page2()
  page3()
  page4()
  page5()
  page6()
  page7()
  page8()
  page9()
  page10()
	
end

function page1()
  if self.pageNumber == 1 then widget.setVisible("page1left", true) elseif self.pageNumber ~= 1 then widget.setVisible("page1left", false) end
  if self.pageNumber == 1 then widget.setVisible("page1right", true) elseif self.pageNumber ~= 1 then widget.setVisible("page1right", false) end
end

function page2()
  --if self.pageNumber == 2 then widget.setVisible("page2left", true) elseif self.pageNumber ~= 2 then widget.setVisible("page2left", false) end
  --if self.pageNumber == 2 then widget.setVisible("page2right", true) elseif self.pageNumber ~= 2 then widget.setVisible("page2right", false) end
	
  if self.pageNumber == 2 then widget.setVisible("imagePage2Left01", true) elseif self.pageNumber ~= 2 then widget.setVisible("imagePage2Left01", false) end
  if self.pageNumber == 2 then widget.setVisible("imagePage2Left02", true) elseif self.pageNumber ~= 2 then widget.setVisible("imagePage2Left02", false) end
  if self.pageNumber == 2 then widget.setVisible("imagePage2Right01", true) elseif self.pageNumber ~= 2 then widget.setVisible("imagePage2Right01", false) end
  if self.pageNumber == 2 then widget.setVisible("imagePage2Right02", true) elseif self.pageNumber ~= 2 then widget.setVisible("imagePage2Right02", false) end
  if self.pageNumber == 2 then widget.setVisible("imagePage2Right03", true) elseif self.pageNumber ~= 2 then widget.setVisible("imagePage2Right03", false) end
end

function page3()
  if self.pageNumber == 3 then widget.setVisible("page3left", true) elseif self.pageNumber ~= 3 then widget.setVisible("page3left", false) end
  if self.pageNumber == 3 then widget.setVisible("page3right", true) elseif self.pageNumber ~= 3 then widget.setVisible("page3right", false) end
	
  if self.pageNumber == 3 then widget.setVisible("imagePage3Left01", true) elseif self.pageNumber ~= 3 then widget.setVisible("imagePage3Left01", false) end
end

function page4()
  if self.pageNumber == 4 then widget.setVisible("page4left", true) elseif self.pageNumber ~= 4 then widget.setVisible("page4left", false) end
  if self.pageNumber == 4 then widget.setVisible("page4right", true) elseif self.pageNumber ~= 4 then widget.setVisible("page4right", false) end
	
  if self.pageNumber == 4 then widget.setVisible("imagePage4Left01", true) elseif self.pageNumber ~= 4 then widget.setVisible("imagePage4Left01", false) end
  --if self.pageNumber == 4 then widget.setVisible("imagePage4Right01", true) elseif self.pageNumber ~= 4 then widget.setVisible("imagePage4Right01", false) end
end

function page5()
  if self.pageNumber == 5 then widget.setVisible("page5left", true) elseif self.pageNumber ~= 5 then widget.setVisible("page5left", false) end
  --if self.pageNumber == 5 then widget.setVisible("page5right", true) elseif self.pageNumber ~= 5 then widget.setVisible("page5right", false) end
	
  if self.pageNumber == 5 then widget.setVisible("imagePage5Left01", true) elseif self.pageNumber ~= 5 then widget.setVisible("imagePage5Left01", false) end
  if self.pageNumber == 5 then widget.setVisible("imagePage5Right01", true) elseif self.pageNumber ~= 5 then widget.setVisible("imagePage5Right01", false) end

end

function page6()
  if self.pageNumber == 6 then widget.setVisible("page6left", true) elseif self.pageNumber ~= 6 then widget.setVisible("page6left", false) end
  if self.pageNumber == 6 then widget.setVisible("page6right", true) elseif self.pageNumber ~= 6 then widget.setVisible("page6right", false) end
	
  if self.pageNumber == 6 then widget.setVisible("imagePage6Left01", true) elseif self.pageNumber ~= 6 then widget.setVisible("imagePage6Left01", false) end
  --if self.pageNumber == 6 then widget.setVisible("imagePage6Right01", true) elseif self.pageNumber ~= 6 then widget.setVisible("imagePage6Right01", false) end

end

function page7()
  if self.pageNumber == 7 then widget.setVisible("page7left", true) elseif self.pageNumber ~= 7 then widget.setVisible("page7left", false) end
  if self.pageNumber == 7 then widget.setVisible("page7right", true) elseif self.pageNumber ~= 7 then widget.setVisible("page7right", false) end
	
  if self.pageNumber == 7 then widget.setVisible("imagePage7Left01", true) elseif self.pageNumber ~= 7 then widget.setVisible("imagePage7Left01", false) end
  --if self.pageNumber == 7 then widget.setVisible("imagePage7Right01", true) elseif self.pageNumber ~= 7 then widget.setVisible("imagePage7Right01", false) end

end

function page8()
  if self.pageNumber == 8 then widget.setVisible("page8left", true) elseif self.pageNumber ~= 8 then widget.setVisible("page8left", false) end
  if self.pageNumber == 8 then widget.setVisible("page8right", true) elseif self.pageNumber ~= 8 then widget.setVisible("page8right", false) end
	
  if self.pageNumber == 8 then widget.setVisible("imagePage8Left01", true) elseif self.pageNumber ~= 8 then widget.setVisible("imagePage8Left01", false) end
  --if self.pageNumber == 8 then widget.setVisible("imagePage8Right01", true) elseif self.pageNumber ~= 8 then widget.setVisible("imagePage8Right01", false) end

end

function page9()
  if self.pageNumber == 9 then widget.setVisible("page9left", true) elseif self.pageNumber ~= 9 then widget.setVisible("page9left", false) end
  if self.pageNumber == 9 then widget.setVisible("page9right", true) elseif self.pageNumber ~= 9 then widget.setVisible("page9right", false) end
	
  if self.pageNumber == 9 then widget.setVisible("imagePage9Left01", true) elseif self.pageNumber ~= 9 then widget.setVisible("imagePage9Left01", false) end
  --if self.pageNumber == 9 then widget.setVisible("imagePage9Right01", true) elseif self.pageNumber ~= 9 then widget.setVisible("imagePage9Right01", false) end

end

function page10()
  if self.pageNumber == 10 then widget.setVisible("page10left", true) elseif self.pageNumber ~= 10 then widget.setVisible("page10left", false) end
  if self.pageNumber == 10 then widget.setVisible("page10right", true) elseif self.pageNumber ~= 10 then widget.setVisible("page10right", false) end
	
  --if self.pageNumber == 10 then widget.setVisible("imagePage10Left01", true) elseif self.pageNumber ~= 10 then widget.setVisible("imagePage10Left01", false) end
  --if self.pageNumber == 10 then widget.setVisible("imagePage10Right01", true) elseif self.pageNumber ~= 10 then widget.setVisible("imagePage10Right01", false) end

end