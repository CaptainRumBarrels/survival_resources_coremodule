require "/scripts/util.lua"

function init()

end

function update() 
	
  status.giveResource("health", 0.1)
  status.giveResource("energy", 0.02)
  status.setResourcePercentage("breath", 1.0)
	
  mcontroller.controlParameters({
     gravityMultiplier = 0.3
  })
	
  if (status.resourcePercentage("survival_resources_resourceManaactive") == 1.0) then
	restoreMana()	
  end
  if (status.resourcePercentage("survival_resources_resourceStaminaactive") == 1.0) then
	restoreStamina()	
  end
  if (status.resourcePercentage("survival_resources_resourceArmouractive") == 1.0) then
    restoreArmour()
  end
  
end

function restoreStamina()
  status.giveResource("survival_resources_resourceStamina", 0.01)	
end

function restoreArmour()
  status.giveResource("survival_resources_resourceArmour", 0.01)	
end

function restoreMana()
  status.giveResource("survival_resources_resourceMana", 0.02)	
end

function restoreSpecial()
  status.giveResource("survival_resources_resourceSpecial", 0.0005)	
end

function uninit()

end