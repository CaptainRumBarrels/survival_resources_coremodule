require "/scripts/util.lua"

function init()

end

function update() 
	
  if (status.resourcePercentage("survival_resources_resourceStaminaactive") == 1.0) then
    status.setResourcePercentage("survival_resources_resourceStamina", 0.99)
  end
  if status.resourcePercentage("food") >= 0.95 then
    status.setResourcePercentage("food", 1.0)
  end
  status.giveResource("health", 0.0125)
  --status.giveResource("energy", 0.15)
  if (status.resourcePercentage("survival_resources_resourceManaactive") == 1.0) then
    status.giveResource("survival_resources_resourceMana", 0.1)
  end
	
  if (status.resourcePercentage("survival_resources_resourceBiowasteactive") == 1.0) then
    if (status.resourcePercentage("survival_resources_resourceBiowaste") <= 0.05) and (status.resourcePercentage("survival_resources_resourceBiowaste2") <= 0.05) then
      status.setResourcePercentage("survival_resources_resourceBiowaste", 0.0)
	  status.setResourcePercentage("survival_resources_resourceBiowaste2", 0.0)
    end
  end
end

function onExpire()

end

function uninit()

end