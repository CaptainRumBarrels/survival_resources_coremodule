--A script to consume an item if the player is low on energy
function init()
  self.item1 = config.getParameter("item1")
  self.item2 = config.getParameter("item2")
  self.item3 = config.getParameter("item3")
  self.item4 = config.getParameter("item4")
  self.item5 = config.getParameter("item5")
  self.item6 = config.getParameter("item6")
  self.item7 = config.getParameter("item7")
	
  self.product1 = config.getParameter("product1")
  self.product2 = config.getParameter("product2")
  self.product3 = config.getParameter("product3")
  self.product4 = config.getParameter("product4")
  self.product5 = config.getParameter("product5")
  self.product6 = config.getParameter("product6")
  self.product7 = config.getParameter("product7")
	
  self.cooldown1 = 0
  self.cooldown2 = 0
  self.cooldown3 = 0
  self.cooldown4 = 0
  self.cooldown5 = 0
  self.cooldown6 = 0
  self.cooldown7 = 0
	
  self.refineinterval = config.getParameter("refineinterval")
  self.quantity = 2
end

function update(dt)
	
  timers(dt)
	
  consumeItem1(dt)
  consumeItem2(dt)
  consumeItem3(dt)
  consumeItem4(dt)
  consumeItem5(dt)
  consumeItem6(dt)
  consumeItem7(dt)
end

function uninit()
  
end

function timers(dt)
  self.cooldown1 = math.max(self.cooldown1 - dt, 0)	
  self.cooldown2 = math.max(self.cooldown2 - dt, 0)	
  self.cooldown3 = math.max(self.cooldown3 - dt, 0)	
  self.cooldown4 = math.max(self.cooldown4 - dt, 0)	
  self.cooldown5 = math.max(self.cooldown5 - dt, 0)	
  self.cooldown6 = math.max(self.cooldown6 - dt, 0)	
  self.cooldown7 = math.max(self.cooldown7 - dt, 0)
end

function consumeItem1(dt)
  playerHasItem1 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item1}) 
  
  local itemCount = 0
  local produceBar1 = false
  local consumedItem1 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item1) or 0)
  
  if itemCount >= self.quantity and not consumedItem1 and self.cooldown1 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item1, count = self.quantity})
    consumedItem1 = true
	produceBar1 = true
	self.cooldown1 = self.refineinterval
  end
	
  if produceBar1 then
    if playerHasItem1 then
	  world.spawnItem(self.product1, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar1 = false
  end
	
  if consumedItem1 then
	consumedItem1 = false
  end	
end

function consumeItem2(dt)
  playerHasItem2 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item2}) 
  
  local itemCount = 0
  local produceBar2 = false
  local consumedItem2 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item2) or 0)
  
  if itemCount >= self.quantity and not consumedItem2 and self.cooldown2 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item2, count = self.quantity})
    consumedItem2 = true
	produceBar2 = true
	self.cooldown2 = self.refineinterval
  end
	
  if produceBar2 then
    if playerHasItem2 then
	  world.spawnItem(self.product2, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar2 = false
  end
	
  if consumedItem2 then
	consumedItem2 = false
  end	
end

function consumeItem3(dt)
  playerHasItem3 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item3}) 
  
  local itemCount = 0
  local produceBar3 = false
  local consumedItem3 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item3) or 0)
  
  if itemCount >= self.quantity and not consumedItem3 and self.cooldown3 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item3, count = self.quantity})
    consumedItem3 = true
	produceBar3 = true
	self.cooldown3 = self.refineinterval
  end
	
  if produceBar3 then
    if playerHasItem3 then
	  world.spawnItem(self.product3, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar3 = false
  end
	
  if consumedItem3 then
	consumedItem3 = false
  end	
end

function consumeItem4(dt)
  playerHasItem4 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item4}) 
  
  local itemCount = 0
  local produceBar4 = false
  local consumedItem4 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item4) or 0)
  
  if itemCount >= self.quantity and not consumedItem4 and self.cooldown4 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item4, count = self.quantity})
    consumedItem4 = true
	produceBar4 = true
	self.cooldown4 = self.refineinterval
  end
	
  if produceBar4 then
    if playerHasItem4 then
	  world.spawnItem(self.product4, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar4 = false
  end
	
  if consumedItem4 then
	consumedItem4 = false
  end	
end

function consumeItem5(dt)
  playerHasItem5 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item5}) 
  
  local itemCount = 0
  local produceBar5 = false
  local consumedItem5 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item5) or 0)
  
  if itemCount >= self.quantity and not consumedItem5 and self.cooldown5 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item5, count = self.quantity})
    consumedItem5 = true
	produceBar5 = true
	self.cooldown5 = self.refineinterval
  end
	
  if produceBar5 then
    if playerHasItem5 then
	  world.spawnItem(self.product5, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar5 = false
  end
	
  if consumedItem5 then
	consumedItem5 = false
  end	
end

function consumeItem6(dt)
  playerHasItem6 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item6}) 
  
  local itemCount = 0
  local produceBar6 = false
  local consumedItem6 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item6) or 0)
  
  if itemCount >= self.quantity and not consumedItem6 and self.cooldown6 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item6, count = self.quantity})
    consumedItem6 = true
	produceBar6 = true
	self.cooldown6 = self.refineinterval
  end
	
  if produceBar6 then
    if playerHasItem6 then
	  world.spawnItem(self.product6, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar6 = false
  end
	
  if consumedItem6 then
	consumedItem6 = false
  end	
end

function consumeItem7(dt)
  playerHasItem7 = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item7}) 
  
  local itemCount = 0
  local produceBar7 = false
  local consumedItem7 = false
  local itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item7) or 0)
  
  if itemCount >= self.quantity and not consumedItem7 and self.cooldown7 == 0 then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item7, count = self.quantity})
    consumedItem7 = true
	produceBar7 = true
	self.cooldown7 = self.refineinterval
  end
	
  if produceBar7 then
    if playerHasItem7 then
	  world.spawnItem(self.product7, mcontroller.position(), 1)
	  status.giveResource("survival_resources_resourceMana", self.resourceBonus)
	  status.giveResource("energy", self.resourceBonus)
	end
	produceBar7 = false
  end
	
  if consumedItem7 then
	consumedItem7 = false
  end	
end