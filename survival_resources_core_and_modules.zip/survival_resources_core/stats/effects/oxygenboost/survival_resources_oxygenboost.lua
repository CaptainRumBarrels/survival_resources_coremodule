function init()
  script.setUpdateDelta(5)

  self.healingRate = config.getParameter("healAmount", 30) / effect.duration()
end

function update(dt)
  if status.resourcePercentage("breath") < 1.0 then
    --status.setResourcePercentage("breath", 1.0)
	status.modifyResource("breath", self.healingRate * dt)
  end
end

function uninit()
  
end