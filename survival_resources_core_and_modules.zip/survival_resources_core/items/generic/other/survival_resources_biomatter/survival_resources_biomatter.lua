function init()
  
end

function update()
  local maxValue = 7
  local minValue = 1
  local itemCount = player.hasCountOfItem("survival_resources_biomatter")
	
  self.randomizeItem = math.floor(math.random(minValue, maxValue))
  self.randomizeQuantity = math.floor(math.random(1, 3))
	
  if self.randomizeItem == 1 then world.spawnItem("plantfibre", entity.position(), self.randomizeQuantity)
    elseif self.randomizeItem == 2 then world.spawnItem("cottonseed", entity.position(), self.randomizeQuantity)
    elseif self.randomizeItem == 3 then world.spawnItem("mushroomseed", entity.position(), 1)
    elseif self.randomizeItem == 4 then world.spawnItem("toxictop", entity.position(), 1)
    elseif self.randomizeItem == 5 then world.spawnItem("kelp", entity.position(), self.randomizeQuantity)
	elseif self.randomizeItem == 6 then world.spawnItem("wheatseed", entity.position(), 1)
	elseif self.randomizeItem == 7 then world.spawnItem("riceseed", entity.position(), 1)
  end

  item.consume(1)
end

function uninit()

end
