-- Melee primary ability
SurvivalResourcesKnifeMeleeSlash = WeaponAbility:new()

function SurvivalResourcesKnifeMeleeSlash:init()
  self.damageConfig.baseDamage = self.baseDps * self.fireTime

  self.energyUsage = self.energyUsage or 0

  self.weapon:setStance(self.stances.idle)

  self.cooldownTimer = self:cooldownTime()

  self.weapon.onLeaveAbility = function()
    self.weapon:setStance(self.stances.idle)
  end
end

-- Ticks on every update regardless if this is the active ability
function SurvivalResourcesKnifeMeleeSlash:update(dt, fireMode, shiftHeld)
  WeaponAbility.update(self, dt, fireMode, shiftHeld)

  self.cooldownTimer = math.max(0, self.cooldownTimer - self.dt)

  if not self.weapon.currentAbility and self.fireMode == (self.activatingFireMode or self.abilitySlot) and self.cooldownTimer == 0 and (self.energyUsage == 0 or not status.resourceLocked("energy")) then
    self:setState(self.windup)
  end
end

-- State: windup
function SurvivalResourcesKnifeMeleeSlash:windup()
  self.weapon:setStance(self.stances.windup)

  if self.stances.windup.hold then
    while self.fireMode == (self.activatingFireMode or self.abilitySlot) do
      coroutine.yield()
    end
  else
    util.wait(self.stances.windup.duration)
  end

  if self.energyUsage then
    status.overConsumeResource("energy", self.energyUsage)
  end

  if self.stances.preslash then
    self:setState(self.preslash)
  else
    self:setState(self.fire)
  end
end

-- State: preslash
-- brief frame in between windup and fire
function SurvivalResourcesKnifeMeleeSlash:preslash()
  self.weapon:setStance(self.stances.preslash)
  self.weapon:updateAim()

  util.wait(self.stances.preslash.duration)

  self:setState(self.fire)
end

function SurvivalResourcesKnifeMeleeSlash:damageTiles()
  local pos = mcontroller.position()
  local tipPosition = vec2.add(pos, activeItem.handPosition(animator.partPoint("blade", "tipPosition")))
  local sourcePosition = vec2.add(pos, activeItem.handPosition(animator.partPoint("blade", "sourcePosition")))
  --Create a list of positions to apply tile damage to. Include sourcePosition immediately as this position is static and not dynamically added
  local miningPositions = {sourcePosition}
  --Calculate tile damage per frame
  local levelMultiplier = 1
  if self.considerLevel then 
    levelMultiplier = config.getParameter("level", 1)
  end
  local tileDamage = levelMultiplier * self.tileDamagePerSwing
  
  --Reset damageTiles at the start of every frame
  self.damagingTiles = false
  
  --Calculate mining positions based on distance between configured tip and source positions
  for i = 1, world.magnitude(tipPosition, sourcePosition) do
	local distanceFactor = 1 / world.magnitude(tipPosition, sourcePosition)
	local position = vec2.add(vec2.mul(world.distance(tipPosition, sourcePosition), (distanceFactor * i)), sourcePosition)
	table.insert(miningPositions, position)
  end
  
  --Optionally damage foreground tiles
  if self.damageForeground and tileDamage > 0 and self.tileDamagePerSwing > 0 then
	if world.damageTiles(miningPositions, "foreground", sourcePosition, self.tileDamageType, tileDamage, 99) then
	  self.damagingTiles = true
	end
  end
  
  --Optionally damage background tiles
  if self.damageBackground and tileDamage > 0 and self.tileDamagePerSwing > 0 then
	if world.damageTiles(miningPositions, "background", sourcePosition, self.tileDamageType, tileDamage, 99) then
	  self.damagingTiles = true
	end
  end
end

-- State: fire
function SurvivalResourcesKnifeMeleeSlash:fire()
  self.weapon:setStance(self.stances.fire)
  self.weapon:updateAim()

  animator.setAnimationState("swoosh", "fire")
  animator.playSound(self.fireSound or "fire")
  animator.burstParticleEmitter((self.elementalType or self.weapon.elementalType) .. "swoosh")
	
  self:damageTiles()

  util.wait(self.stances.fire.duration, function()
    local damageArea = partDamageArea("swoosh")
    self.weapon:setDamage(self.damageConfig, damageArea, self.fireTime)
    --world.damageTileArea(mcontroller.position() , 1.5, "foreground", mcontroller.position(), "plantish", 0.1, 99)
  end)

  self.cooldownTimer = self:cooldownTime()
end

function SurvivalResourcesKnifeMeleeSlash:cooldownTime()
  return self.fireTime - self.stances.windup.duration - self.stances.fire.duration
end

function SurvivalResourcesKnifeMeleeSlash:uninit()
  self.weapon:setDamage()
end
