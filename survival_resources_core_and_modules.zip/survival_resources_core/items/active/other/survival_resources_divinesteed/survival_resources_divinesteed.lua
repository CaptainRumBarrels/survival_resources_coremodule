require "/scripts/vec2.lua"
require "/scripts/util.lua"
require "/scripts/activeitem/stances.lua"

function init()
  self.fireOffset = config.getParameter("fireOffset")
  updateAim()
  self.playingsound = false
  self.fireSteed = false
end

function activate(fireMode, shiftHeld)
  
end

function update(dt, fireMode, shiftHeld)
  if fireMode == "primary" and (status.resourcePercentage("survival_resources_resourceSpecial") >= 0.5) and not self.fireSteed then
    self.fireSteed = true
	local projectileParameters = {
      power = 75,
      powerMultiplier = 1,
      speed = 50
    }
    world.spawnProjectile(
      "survival_resources_steed",
      vec2.add(activeItem.ownerAimPosition(), {0.0, 60.0}),
      activeItem.ownerEntityId(),
      {0.0, -8.0},
      false,
	  projectileParameters
    )
	status.consumeResource("survival_resources_resourceSpecial", 50)
		
  if not self.playingsound then
    animator.playSound("fire")
	self.playingsound = true
	--item.consume(1)
  end

  else
	updateAim()
  end
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffset[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(self.aimAngle)
  activeItem.setFacingDirection(self.aimDirection)
end

function uninit()
  
end
