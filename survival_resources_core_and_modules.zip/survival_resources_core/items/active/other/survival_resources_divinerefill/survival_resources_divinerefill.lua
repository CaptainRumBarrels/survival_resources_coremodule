require "/scripts/vec2.lua"
require "/scripts/util.lua"
require "/scripts/activeitem/stances.lua"

function init()
  self.fireOffset = config.getParameter("fireOffset")
  updateAim()
  self.playingsound = false
end

function activate(fireMode, shiftHeld)
  
end

function update(dt, fireMode, shiftHeld)
  if fireMode == "primary" and (status.resourcePercentage("survival_resources_resourceSpecial") == 1.0) then

	status.resetResource("survival_resources_resourceMana")
	status.resetResource("survival_resources_resourceStamina")
	status.resetResource("energy")
	status.resetResource("breath")
	status.resetResource("health")
	status.resetResource("food")
	status.resetResource("survival_resources_resourceBiowaste")
	status.resetResource("survival_resources_resourceBiowaste2")
	status.consumeResource("survival_resources_resourceSpecial", 100)
		
  if not self.playingsound then
    animator.playSound("fire")
	self.playingsound = true
	item.consume(1)
  end

  else
	updateAim()
  end
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffset[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(self.aimAngle)
  activeItem.setFacingDirection(self.aimDirection)
end

function uninit()
  
end
