require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()

end

function activate(fireMode, shiftHeld, dt)
  if status.resourcePercentage("survival_resources_resourceSpecial") >= 0.25 then
	status.consumeResource("survival_resources_resourceSpecial", 25)
	player.warp("OwnShip")
	status.addEphemeralEffect("survival_resources_blink", 2)
  end
end

function update(dt)

end

function uninit()

end
