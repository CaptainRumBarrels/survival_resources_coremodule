function init()
  self.openInterface = false
end

function activate(fireMode, shiftHeld)
  if status.resourcePercentage("interfaceResourceLogic1") == 1.0 and not self.openInterface then
    activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
	self.openInterface = true
  end
  
  status.setResourcePercentage("interfaceResourceLogic1", 1.0)
end

function update()
  if status.resourcePercentage("interfaceResourceLogic1") == 0.0 then
    self.openInterface = false
  end
end

function uninit()
  self.openInterface = false
end
