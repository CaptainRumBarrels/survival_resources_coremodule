require "/scripts/util.lua"
require "/scripts/vec2.lua"
require "/items/active/weapons/ranged/gunfire.lua"
require "/scripts/survival_resources_rope.lua"

ZipLine = GunFire:new()

function ZipLine:init()
  self.chains = {}

  self.cooldownTimer = 0
  self.swingDelay = 0
	
  self.breakDistance = 5
  self.groundCheck = false
	
  self.projectileId = nil
  self.projectilePosition = nil
	
  self.ziplineOffset = config.getParameter("ziplineOffset")

  self.weapon:setStance(self.stances.idle)
  self.weapon.onLeaveAbility = function()
    self:killProjectiles()
  end
end

function ZipLine:killProjectiles()
  for _,chain in pairs(self.chains) do
    if world.entityExists(chain.targetEntityId) then
      world.callScriptedEntity(chain.targetEntityId, "kill")
    end
  end
  activeItem.setHoldingItem(true)
  status.removeEphemeralEffect("survival_resources_zipline")
  self.groundCheck = false
end

function ZipLine:trackProjectile()
  if self.projectileId then
    if world.entityExists(self.projectileId) then
      local position = mcontroller.position()
      self.projectilePosition = vec2.add(world.distance(world.entityPosition(self.projectileId), position), position)
    else
      self:killProjectiles()
    end
  end
end

function ZipLine:uninit()
  self:killProjectiles()
end

function ZipLine:shouldFire()
  return self.fireMode == (self.activatingFireMode or self.abilitySlot)
      and self.cooldownTimer == 0
      and #self.chains < self.maxProjectiles
      and not status.resourceLocked("energy")
      and not world.lineTileCollision(mcontroller.position(), self:firePosition())
end

function ZipLine:update(dt, fireMode, shiftHeld)
  WeaponAbility.update(self, dt, fireMode, shiftHeld)
  self:trackProjectile()
  self.cooldownTimer = math.max(0, self.cooldownTimer - self.dt)
  self.swingDelay = math.max(0, self.swingDelay - self.dt)	
	
  if fireMode == "alt" and self.previousFireMode ~= "alt" then
	self:killProjectiles()
  end

  if self:shouldFire() and not self.weapon.currentAbility then
    self:setState(self.firing)
  end
end

function ZipLine:firing()
  self.weapon:setStance(self.stances.fire)
  self.swingDelay = 0.75

  self:fire()

  while #self.chains > 0 do
    if self:shouldFire() then
      self:fire()
    end
    if self.fireMode == (self.activatingFireMode or self.abilitySlot) and self.swingDelay == 0 then
      local boostAngle = mcontroller.facingDirection() == -1 and -self.weapon.aimAngle - math.pi or self.weapon.aimAngle
	  local estimatedPosition = mcontroller.position()
	  local angle = math.atan(estimatedPosition[2] - world.entityPosition(projectileId)[2], estimatedPosition[1] - world.entityPosition(projectileId)[1])
      mcontroller.controlApproachVelocityAlongAngle(angle, -15, 200, false)
    else
	  mcontroller.controlApproachXVelocity(0, 300)
	  mcontroller.controlApproachYVelocity(0, 20)			
    end
	activeItem.setHoldingItem(false)
	if mcontroller.onGround() then
	  self.groundCheck = true
	end
	if self.groundCheck then
	  status.addEphemeralEffect("survival_resources_zipline")
	end
    self:updateZipline()
    coroutine.yield()
  end

  self.weapon:setStance(self.stances.idle)
end

function ZipLine:fire()
  status.overConsumeResource("energy", self.energyUsage * self.fireTime)

  for i = 1, math.min(self.projectileCount, self.maxProjectiles - #self.chains) do
    local projectileParameters = {
        damageTeam = world.entityDamageTeam(activeItem.ownerEntityId()),
        power = self:damagePerShot(),
        powerMultiplier = activeItem.ownerPowerMultiplier()
      }
    util.mergeTable(projectileParameters, self.projectileParameters)
    projectileId = world.spawnProjectile(
        self.projectileType,
        self:firePosition(),
        activeItem.ownerEntityId(),
        self:aimVector(self.inaccuracy),
        false,
        projectileParameters
      )
    projectileId2 = world.spawnProjectile(
        self.projectileType,
        mcontroller.position(),
        activeItem.ownerEntityId(),
        {0,-1},
        false,
        projectileParameters
      )
		
    self:addProjectile(projectileId)
	self:addProjectile(projectileId2)
  end

  animator.playSound(self.fireSound)

  self.cooldownTimer = self.fireTime
  --activeItem.setHoldingItem(false)
end

function ZipLine:addProjectile(projectileId)
  local newChain = copy(self.chain)
  newChain.targetEntityId = projectileId

  newChain.startOffset = vec2.add(newChain.startOffset or {0,0}, self.weapon.muzzleOffset)

  table.insert(self.chains, newChain)
end

function ZipLine:addProjectile2(projectileId2)

end

function ZipLine:updateZipline()
  self.chains = util.filter(self.chains, function (chain)
      return chain.targetEntityId and world.entityExists(chain.targetEntityId)
    end)

  activeItem.setScriptedAnimationParameter("chains", self.chains)
end

function ZipLine:aimVector(inaccuracy)
  local aimVector = vec2.rotate({1, 0}, (self.fireAngle or self.weapon.aimAngle) + sb.nrand(inaccuracy, 0))
  aimVector[1] = aimVector[1] * mcontroller.facingDirection()
  return aimVector
end