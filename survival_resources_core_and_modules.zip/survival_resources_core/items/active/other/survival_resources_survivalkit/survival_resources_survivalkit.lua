function init()
  self.openBag = false
end

function activate(fireMode, shiftHeld)
  if not self.openBag then
	itemList()
	self.openBag = true
	item.consume(1)
  end
end

function update()
  if self.openBag then
    self.openBag = false
	item.consume(1)
  end
end

function itemList()
  player.giveItem("survival_resources_knife")
  player.giveItem("survival_resources_pistol")
  player.giveItem("survival_resources_waterbottle")
  player.giveItem("survival_resources_manual")
  player.giveItem("sleepingbaggreen")
	
  player.giveItem("survival_resources_ammoreload1")
  player.giveItem("survival_resources_ammoreload1")
  player.giveItem("survival_resources_ammoreload1")
  player.giveItem("survival_resources_ammoreload1")
  player.giveItem("survival_resources_ammoreload1")
  player.giveItem("survival_resources_ammoreload1")
	
  player.giveItem("survival_resources_toiletpaper")
  player.giveItem("survival_resources_toiletpaper")
  player.giveItem("survival_resources_toiletpaper")
  player.giveItem("survival_resources_toiletpaper")
  player.giveItem("survival_resources_toiletpaper")
  player.giveItem("survival_resources_toiletpaper")
end

function uninit()
  self.openBag = false
end
