require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
	
  sb.logInfo("-----Survival Artificial Resource Initialising...-----")
	
  ---Artificial Resources Initialisation---
  self.openInterface = false
  self.startupInterface = false
	
  --if (animator.animationState("interface") == "off") then
	--animator.setAnimationState("interface", "on")
	if status.resourcePercentage("interfaceResourceLogic1") == 1.0 and not self.startupInterface then --and (animator.animationState("interface") == "on") then
	  --world.sendEntityMessage(entity.id(),"interact","ScriptPane","/interface/scripted/resources/survival_resources_resourceinterface3.config")
	  player.interact("ScriptPane","/interface/scripted/resources/survival_resources_resourceinterface3.config")
	  self.startupInterface = true
	  --(animator.animationState("interface") == "off")
	  --animator.setAnimationState("interface", "off")
	end
  --end
  
  sb.logInfo("-----Survival Artificial Resource Initialised!-----")
end

function update(dt)
  ---Open Interface---
  openInterface()
end

function openInterface()
	
  if player.primaryHandItem("beamaxe") or player.primaryHandItem("wiretool") or player.primaryHandItem("painttool") or player.primaryHandItem("scanmode") or player.primaryHandItem("inspectionmode") then --and status.resourcePercentage("interfaceResourceLogic1") == 1.0 then
   if not self.openInterface then
     self.openInterface = true
	 if status.resourcePercentage("interfaceResourceLogic1") == 1.0 then
	   player.interact("ScriptPane","/interface/scripted/resources/survival_resources_resourceinterface3.config")
	 end
   end
  elseif not player.primaryHandItem("beamaxe") or not player.primaryHandItem("wiretool") or not player.primaryHandItem("painttool") or not player.primaryHandItem("scanmode") or not player.primaryHandItem("inspectionmode") then
    if self.openInterface then
	  self.openInterface = false	
	end
  end
  
  status.addEphemeralEffect("survival_resource_openinterfacetrigger", 3)--cannot open interface with entity query for some reason. status effect may work.
end

function uninit()
	
end