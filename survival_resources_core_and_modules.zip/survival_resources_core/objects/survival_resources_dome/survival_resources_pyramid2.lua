require "/scripts/vec2.lua"

function init()
  self.detectWallArea = config.getParameter("wallPositions") 
  self.damageWallArea = config.getParameter("wallPositions")
  self.waterSpawnPoint = config.getParameter("waterspawnpoint") 
	
  self.door1Position = config.getParameter("doorPosition1")
  self.door2Position = config.getParameter("doorPosition2")
  self.door1Placed = false
  self.door2Placed = false
	
  self.tileProtected = false
	
  self.red1 = 255
  self.green1 = 0
  self.blue1 = 0
	
  self.red2 = 0
  self.green2 = 255
  self.blue2 = 0

  self.red3 = 0
  self.green3 = 0
  self.blue3 = 255
	
  self.red4 = 255
  self.green4 = 255
  self.blue4 = 0
	
  self.red5 = 0
  self.green5 = 255
  self.blue5 = 255
	
  self.red6 = 255
  self.green6 = 0
  self.blue6 = 255
	
  self.red7 = 0
  self.green7 = 0
  self.blue7 = 0
	
  self.red8 = 0
  self.green8 = 255
  self.blue8 = 0
	
  self.colourLimit = 255
	
  self.red1ShiftUp = true
  self.green1ShiftUp = true
  self.blue1ShiftUp = true

  --self.playSound = false
end

function update(dt)

  world.spawnProjectile("water", vec2.add(entity.position(), {26.0, 24.0}), entity.id(), {0.0,0.0}, false)
  world.spawnProjectile("water", vec2.add(entity.position(), {26.0, 24.0}), entity.id(), {0.0,0.0}, false)
  world.spawnProjectile("water", vec2.add(entity.position(), {26.0, 24.0}), entity.id(), {0.0,0.0}, false)

  lights()
  spawnWall()	
  placeObjects()
end

function placeObjects()
  if not self.door1Placed then
    for _, door1Position in ipairs(self.door1Position) do
      door1Position = vec2.add(door1Position, entity.position())
	  world.placeObject("survival_resources_pyramiddoor", door1Position, -1)
    end
	self.door1Placed = true
  end
  if not self.door2Placed then
    for _, door2Position in ipairs(self.door2Position) do
      door2Position = vec2.add(door2Position, entity.position())
	  world.placeObject("survival_resources_pyramiddoor", door2Position, 1)
    end
	self.door2Placed = true
  end
end
	
function spawnWall()
  if #self.detectWallArea > 0 then
    for _, wallPosition in ipairs(self.detectWallArea) do
      wallPosition = vec2.add(wallPosition, entity.position())
	  world.placeMaterial(wallPosition, "background", "survival_resources_hubwall", 0, true)
	end
  end
end

function die(smash)
  if #self.damageWallArea > 0 then
    for _, damageWallPosition in ipairs(self.damageWallArea) do
      damageWallPosition = vec2.add(damageWallPosition, entity.position())
	  if world.material(damageWallPosition, "background") == "survival_resources_hubwall" then
	    world.damageTileArea(damageWallPosition, 0.8, "background", damageWallPosition, "blockish", 10000, 0)
	  end
	end
  end 
end

function uninit()
  
end

function lights()
  local lightAngleRight = 315
  local lightAngleLeft = 225
  local lightAngleCeiling = 270
	
  animator.setLightPointAngle("light1", lightAngleLeft)
  animator.setLightPointAngle("light2", lightAngleRight)
  animator.setLightPointAngle("light3", lightAngleCeiling)
  animator.setLightPointAngle("light4", 90)
  animator.setLightPointAngle("light5", 295)	
  animator.setLightPointAngle("light6", 245)	
  animator.setLightPointAngle("light7", 280)	
  animator.setLightPointAngle("light8", 260)	

  animator.setLightColor("light1", {self.red1, self.green1, self.blue1, 255})
  animator.setLightColor("light2", {self.red2, self.green2, self.blue2, 255})
  animator.setLightColor("light3", {self.red3, self.green3, self.blue3, 255})
  animator.setLightColor("light4", {self.red4, self.green4, self.blue4, 255})
  animator.setLightColor("light5", {self.red5, self.green5, self.blue5, 255})
  animator.setLightColor("light6", {self.red6, self.green6, self.blue6, 255})
  animator.setLightColor("light7", {self.red7, self.green7, self.blue7, 255})
  animator.setLightColor("light8", {self.red8, self.green8, self.blue8, 255})
	
  if self.red1 >= 255 then self.red1 = 255 end
  if self.green1 >= 255 then self.green1 = 255 end
  if self.blue1 >= 255 then self.blue1 = 255 end
	
  if self.red2 >= 255 then self.red2 = 255 end
  if self.green2 >= 255 then self.green2 = 255 end
  if self.blue2 >= 255 then self.blue2 = 255 end
	
  if self.red3 >= 255 then self.red3 = 255 end
  if self.green3 >= 255 then self.green3 = 255 end
  if self.blue3 >= 255 then self.blue3 = 255 end
	
  if self.red4 >= 255 then self.red4 = 255 end
  if self.green4 >= 255 then self.green4 = 255 end
  if self.blue4 >= 255 then self.blue4 = 255 end
	
  if self.red5 >= 255 then self.red5 = 255 end
  if self.green5 >= 255 then self.green5 = 255 end
  if self.blue5 >= 255 then self.blue5 = 255 end
	
  if self.red6 >= 255 then self.red6 = 255 end
  if self.green6 >= 255 then self.green6 = 255 end
  if self.blue6 >= 255 then self.blue6 = 255 end
	
  if self.red7 >= 255 then self.red7 = 255 end
  if self.green7 >= 255 then self.green7 = 255 end
  if self.blue7 >= 255 then self.blue7 = 255 end
	
  if self.red8 >= 255 then self.red8 = 255 end
  if self.green8 >= 255 then self.green8 = 255 end
  if self.blue8 >= 255 then self.blue8 = 255 end
	
  if self.red1 < 255 and self.green1 <= 0 and self.blue1 <= 0 then
    self.red1 = self.red1 + 5
  elseif self.red1 == 255 and self.green1 < 255 and self.blue1 <= 0 then
	self.green1 = self.green1 + 5
  elseif self.red1 > 0 and self.green1 == 255 and self.blue1 <= 0 then
	self.red1 = self.red1 - 5
  elseif self.red1 <= 0 and self.green1 == 255 and self.blue1 < 255 then 
	self.blue1 = self.blue1 + 5
  elseif self.red1 <= 0 and self.green1 > 0 and self.blue1 == 255 then
    self.green1 = self.green1 - 5
  elseif self.red1 < 255 and self.green1 <= 0 and self.blue1 == 255 then
    self.red1 = self.red1 + 5
  elseif self.red1 == 255 and self.green1 <= 0 and self.blue1 > 0 then
	self.blue1 = self.blue1 - 5
  end
	
  if self.red2 < 255 and self.green2 <= 0 and self.blue2 <= 0 then
    self.red2 = self.red2 + 5
  elseif self.red2 == 255 and self.green2 < 255 and self.blue2 <= 0 then
	self.green2 = self.green2 + 5
  elseif self.red2 > 0 and self.green2 == 255 and self.blue2 <= 0 then
	self.red2 = self.red2 - 5
  elseif self.red2 <= 0 and self.green2 == 255 and self.blue2 < 255 then 
	self.blue2 = self.blue2 + 5
  elseif self.red2 <= 0 and self.green2 > 0 and self.blue2 == 255 then
    self.green2 = self.green2 - 5
  elseif self.red2 < 255 and self.green2 <= 0 and self.blue2 == 255 then
    self.red2 = self.red2 + 5
  elseif self.red2 == 255 and self.green2 <= 0 and self.blue2 > 0 then
	self.blue2 = self.blue2 - 5
  end
	
  if self.red3 < 255 and self.green3 <= 0 and self.blue3 <= 0 then
    self.red3 = self.red3 + 5
  elseif self.red3 == 255 and self.green3 < 255 and self.blue3 <= 0 then
	self.green3 = self.green3 + 5
  elseif self.red3 > 0 and self.green3 == 255 and self.blue3 <= 0 then
	self.red3 = self.red3 - 5
  elseif self.red3 <= 0 and self.green3 == 255 and self.blue3 < 255 then 
	self.blue3 = self.blue3 + 5
  elseif self.red3 <= 0 and self.green3 > 0 and self.blue3 == 255 then
    self.green3 = self.green3 - 5
  elseif self.red3 < 255 and self.green3 <= 0 and self.blue3 == 255 then
    self.red3 = self.red3 + 5
  elseif self.red3 == 255 and self.green3 <= 0 and self.blue3 > 0 then
	self.blue3 = self.blue3 - 5
  end
	
  if self.red4 < 255 and self.green4 <= 0 and self.blue4 <= 0 then
    self.red4 = self.red4 + 15
  elseif self.red4 == 255 and self.green4 < 255 and self.blue4 <= 0 then
	self.green4 = self.green4 + 15
  elseif self.red4 > 0 and self.green4 == 255 and self.blue4 <= 0 then
	self.red4 = self.red4 - 15
  elseif self.red4 <= 0 and self.green4 == 255 and self.blue4 < 255 then 
	self.blue4 = self.blue4 + 15
  elseif self.red4 <= 0 and self.green4 > 0 and self.blue4 == 255 then
    self.green4 = self.green4 - 15
  elseif self.red4 < 255 and self.green4 <= 0 and self.blue4 == 255 then
    self.red4 = self.red4 + 15
  elseif self.red4 == 255 and self.green4 <= 0 and self.blue4 > 0 then
	self.blue4 = self.blue4 - 15
  end
	
  if self.red5 < 255 and self.green5 <= 0 and self.blue5 <= 0 then
    self.red5 = self.red5 + 5
  elseif self.red5 == 255 and self.green5 < 255 and self.blue5 <= 0 then
	self.green5 = self.green5 + 5
  elseif self.red5 > 0 and self.green5 == 255 and self.blue5 <= 0 then
	self.red5 = self.red5 - 5
  elseif self.red5 <= 0 and self.green5 == 255 and self.blue5 < 255 then 
	self.blue5 = self.blue5 + 5
  elseif self.red5 <= 0 and self.green5 > 0 and self.blue5 == 255 then
    self.green5 = self.green5 - 5
  elseif self.red5 < 255 and self.green5 <= 0 and self.blue5 == 255 then
    self.red5 = self.red5 + 5
  elseif self.red5 == 255 and self.green5 <= 0 and self.blue5 > 0 then
	self.blue5 = self.blue5 - 5
  end
	
  if self.red6 < 255 and self.green6 <= 0 and self.blue6 <= 0 then
    self.red6 = self.red6 + 5
  elseif self.red6 == 255 and self.green6 < 255 and self.blue6 <= 0 then
	self.green6 = self.green6 + 5
  elseif self.red6 > 0 and self.green6 == 255 and self.blue6 <= 0 then
	self.red6 = self.red6 - 5
  elseif self.red6 <= 0 and self.green6 == 255 and self.blue6 < 255 then 
	self.blue6 = self.blue6 + 5
  elseif self.red6 <= 0 and self.green6 > 0 and self.blue6 == 255 then
    self.green6 = self.green6 - 5
  elseif self.red6 < 255 and self.green6 <= 0 and self.blue6 == 255 then
    self.red6 = self.red6 + 5
  elseif self.red6 == 255 and self.green6 <= 0 and self.blue6 > 0 then
	self.blue6 = self.blue6 - 5
  end
	
  if self.red7 < 255 and self.green7 <= 0 and self.blue7 <= 0 then
    self.red7 = self.red7 + 1
  elseif self.red7 == 255 and self.green7 < 255 and self.blue7 <= 0 then
	self.green7 = self.green7 + 1
  elseif self.red7 > 0 and self.green7 == 255 and self.blue7 <= 0 then
	self.red7 = self.red7 - 1
  elseif self.red7 <= 0 and self.green7 == 255 and self.blue7 < 255 then 
	self.blue7 = self.blue7 + 1
  elseif self.red7 <= 0 and self.green7 > 0 and self.blue7 == 255 then
    self.green7 = self.green7 - 1
  elseif self.red7 < 255 and self.green7 <= 0 and self.blue7 == 255 then
    self.red7 = self.red7 + 1
  elseif self.red7 == 255 and self.green7 <= 0 and self.blue7 > 0 then
	self.blue7 = self.blue7 - 1
  end
	
  if self.red8 < 255 and self.green8 <= 0 and self.blue8 <= 0 then
    self.red8 = self.red8 + 1
  elseif self.red8 == 255 and self.green8 < 255 and self.blue8 <= 0 then
	self.green8 = self.green8 + 1
  elseif self.red8 > 0 and self.green8 == 255 and self.blue8 <= 0 then
	self.red8 = self.red8 - 1
  elseif self.red8 <= 0 and self.green8 == 255 and self.blue8 < 255 then 
	self.blue8 = self.blue8 + 1
  elseif self.red8 <= 0 and self.green8 > 0 and self.blue8 == 255 then
    self.green8 = self.green8 - 1
  elseif self.red8 < 255 and self.green8 <= 0 and self.blue8 == 255 then
    self.red8 = self.red8 + 1
  elseif self.red8 == 255 and self.green8 <= 0 and self.blue8 > 0 then
	self.blue8 = self.blue8 - 1
  end
  
end
