require "/scripts/util.lua"
require "/scripts/vec2.lua"

function init()
  self.supplycratetopPosition = config.getParameter("supplycratetop")
  self.supplycratetopPlaced = false
end

function update()
  placeObects()
end

function placeObects()
  if not self.supplycratetopPlaced then
    for _, supplycratetopPosition in ipairs(self.supplycratetopPosition) do
      supplycratetopPosition = vec2.add(supplycratetopPosition, entity.position())
	  if object.direction() == -1 then
	    world.placeObject("survival_resources_supplycratetop", supplycratetopPosition, -1)
	  elseif object.direction() == 1 then
		world.placeObject("survival_resources_supplycratetop", supplycratetopPosition, 1)
	  end
    end
	self.supplycratetopPlaced = true
  end
end
