require "/scripts/vec2.lua"

function init()
  self.detectDrainArea = config.getParameter("drainPositions")
  self.detectWallArea = config.getParameter("wallPositions")
  self.damageWallArea = config.getParameter("wallPositions")
  self.spawnTile = false
end

function update(dt)

  drain()
	
  object.setHealth(object.health() - 2.5)
  destroyBlocks()
  --if object.health() == 0 then
	--spawnWall()
	--destroyBlocks()
  --end
	
  if #self.detectDrainArea > 0 then
    for _, drainPosition in ipairs(self.detectDrainArea) do
      drainPosition = vec2.add(drainPosition, entity.position())
      world.debugPoint(drainPosition, "yellow")
    end
  end
	
  if not self.spawnTile then
	self.spawnTile = true
	--spawnWall()
  end
end

-- Removes Liquids at current position
function drain()
  if #self.detectDrainArea > 0 then
    for _, drainPosition in ipairs(self.detectDrainArea) do
      drainPosition = vec2.add(drainPosition, entity.position())
	  if world.liquidAt(drainPosition) then
        world.forceDestroyLiquid(drainPosition)
      end
	end
  end
end
	
function spawnWall()
  if #self.detectWallArea > 0 then
    for _, wallPosition in ipairs(self.detectWallArea) do
      wallPosition = vec2.add(wallPosition, entity.position())
	  world.placeMaterial(wallPosition, "foreground", "survival_resources_dirt", 0, true)
	  world.placeMod(wallPosition, "foreground", "tilled", 0, true)
	end
  end
end
	
function destroyBlocks()
  if #self.damageWallArea > 0 then
    for _, damagePosition in ipairs(self.damageWallArea) do
      damagePosition = vec2.add(damagePosition, entity.position())
	  world.damageTileArea(damagePosition, 0.8, "foreground", damagePosition, "blockish", 10000, 0)
	end
  end		
end

function die(smash)
  destroyBlocks()
end

function uninit()

end
