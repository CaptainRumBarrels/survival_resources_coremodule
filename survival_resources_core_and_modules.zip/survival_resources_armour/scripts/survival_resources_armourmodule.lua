require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.firstInterval = false
  self.secondInterval = false
	
  self.healthValueT1 = status.resource("health")
  self.healthValueT2 = status.resource("health")
	
  self.queryDamageSince = 0 
	
  self.hit = false
  self.cooldown = 0 
end

function update(dt)
  self.cooldown = math.floor(self.cooldown, self.cooldown - dt)
	
  intervalTimer()
  resourceArmour(dt)
  adminDefaults()
  racialBonus()
	
  status.setResourcePercentage("survival_resources_resourceArmouractive", 1.0)	
end

function adminDefaults()
  if player.isAdmin() then
    status.setResourcePercentage("survival_resources_resourceArmour", 1.0)	
  end
end

function intervalTimer()
  if not self.firstInterval and not self.secondInterval then
    self.firstInterval = true
	self.secondInterval = false
  elseif self.firstInterval and not self.secondInterval then
    self.firstInterval = false
	self.secondInterval = true
	  
	logResourceValueAtT1()
  elseif not self.firstInterval and self.secondInterval then
	self.firstInterval = true
	self.secondInterval = false
	  
	logResourceValueAtT2()
  end
end

function logResourceValueAtT1()
  self.healthValueT1 = status.resource("health")
end

function logResourceValueAtT2()    
  self.healthValueT2 = status.resource("health")
end

function resourceArmour(dt)
  local healthDifference = math.abs(self.healthValueT1 - self.healthValueT2) -- Becase we are dealing with reduction, no addition, we subtract second value from first.
  local damageNotifications, nextStep = status.damageTakenSince(self.queryDamageSince)
  self.queryDamageSince = nextStep
  if #damageNotifications > 0 then
	status.overConsumeResource("survival_resources_resourceArmour", healthDifference / 10)
	if not self.hit and self.cooldown == 0 then
	  self.hit = true
	end
  end
	
  if self.hit and self.cooldown == 0 then
    --status.addEphemeralEffect("survival_resources_inflictdamage", 0.01)
	self.cooldown = 1
	self.hit = false
  end
	
  if status.resourcePercentage("survival_resources_resourceArmour") > 0 then
    status.addEphemeralEffect("survival_resources_armourbonus", 0.2)
  elseif status.resourcePercentage("survival_resources_resourceArmour") == 0 then
	status.removeEphemeralEffect("survival_resources_armourbonus")
  end
end

function racialBonus()
  if world.entitySpecies(player.id()) == "glitch" then
    if (status.resourcePercentage("survival_resources_resourceArmour") <= 0.5) and player.isLounging() then
	  status.giveResource("survival_resources_resourceArmour", 0.01)
	end  	
  end
end

function uninit()
	
end