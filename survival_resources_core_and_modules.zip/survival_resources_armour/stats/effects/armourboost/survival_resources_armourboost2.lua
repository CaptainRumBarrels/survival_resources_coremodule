function init()
  --script.setUpdateDelta(5)
  self.fixingArmour = false
end

function update(dt)
  if not self.fixingArmour then
    status.giveResource("survival_resources_resourceArmour", 10)
	self.fixingArmour = true
  end
end

function uninit()
  self.fixingArmour = false
end