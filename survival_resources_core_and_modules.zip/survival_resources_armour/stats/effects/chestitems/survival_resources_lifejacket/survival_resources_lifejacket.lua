require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.spawnBubbleInterval = 0.5
  self.bubbleSpawnerTimer = 0
end

function update(dt)
	
  mcontroller.controlParameters({
    liquidBuoyancy = 1.75,
	liquidFriction = 1.5,
	liquidImpedance = 0.5,
	liquidForce = 40
  })
	
  self.bubbleSpawnerTimer = self.bubbleSpawnerTimer - script.updateDt()
  
  local min = 0
  local max = 1
  local interval = math.random(min, max)
  if (self.bubbleSpawnerTimer <= 0) then
    self.bubbleSpawnerTimer = interval / 30
		
	self.randX1Velocity = math.random(0, 1)
	self.randX2Velocity = math.random(0, 5)
	self.randX3Velocity = math.random(0, 8)
		
	self.randY1Velocity = math.random(0, 2)
	self.randY2Velocity = math.random(0, 5)
	self.randY3Velocity = math.random(0, 8)
  end
	
  if mcontroller.liquidMovement() and mcontroller.liquidPercentage() >= 0.5 then
		
  if mcontroller.facingDirection() == 1 then
    if mcontroller.xVelocity() < 0.5 or mcontroller.xVelocity() == 0 then
	  mcontroller.setRotation(0.6)
    end
    if mcontroller.xVelocity() >= 0.5 then
	  mcontroller.setRotation(0)
    end
	if mcontroller.xVelocity() >= 8.5 then
	  --status.addEphemeralEffect("glow")
	  if (self.bubbleSpawnerTimer <= 0) then
		spawnBubbles(dt)
      end
    else
      --status.removeEphemeralEffect("glow")
    end
  end
		
  if mcontroller.facingDirection() == -1 then
	
    if mcontroller.xVelocity() < -0.5 or mcontroller.xVelocity() == 0 then
	  mcontroller.setRotation(0)
    end
    if mcontroller.xVelocity() >= -0.5 then
	  mcontroller.setRotation(-0.6)
    end
    if mcontroller.xVelocity() >= -8.5 then
	  --status.removeEphemeralEffect("glow")
    else
      --status.addEphemeralEffect("glow")
	  if (self.bubbleSpawnerTimer <= 0) then
		spawnBubbles(dt)
      end
    end
  end
		
  else
	mcontroller.setRotation(0)
  end
end

function spawnBubbles(dt)
  local projectileParameters = {
    power = 0,
    powerMultiplier = 0
  }
  if mcontroller.facingDirection() == -1 then
    world.spawnProjectile("survival_resources_lifejacketspray", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {(self.randX1Velocity * 1),self.randY1Velocity}, false, projectileParameters)
    world.spawnProjectile("survival_resources_lifejacketspray", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {(self.randX2Velocity * -1),self.randY2Velocity}, false, projectileParameters)
    world.spawnProjectile("survival_resources_lifejacketspray", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {(self.randX3Velocity * 1),self.randY3Velocity}, false, projectileParameters)
  elseif mcontroller.facingDirection() == 1 then
    world.spawnProjectile("survival_resources_lifejacketspray", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {(self.randX1Velocity * -1),self.randY1Velocity}, false, projectileParameters)
    world.spawnProjectile("survival_resources_lifejacketspray", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {(self.randX2Velocity * 1),self.randY2Velocity}, false, projectileParameters)
    world.spawnProjectile("survival_resources_lifejacketspray", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {(self.randX3Velocity * -1),self.randY3Velocity}, false, projectileParameters)		
  end
end

function uninit()
  mcontroller.setRotation(0)
end