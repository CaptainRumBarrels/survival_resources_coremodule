function init()
  script.setUpdateDelta(5)
  self.applyDamage = false
end

function update(dt)

  if not self.applyDamage then
    status.applySelfDamageRequest({
        damageType = "IgnoresDef",
        damage = 2,
        damageSourceKind = "default",
        sourceEntityId = entity.id()
      })
  self.applyDamage = true
  end
	
  if effect.duration() and self.applyDamage then
    effect.expire()
  end
	
end

function uninit()
  
end
