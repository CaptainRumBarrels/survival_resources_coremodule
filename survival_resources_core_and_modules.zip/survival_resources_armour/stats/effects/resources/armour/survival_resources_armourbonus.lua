function init()
  self.protectionModifier = 0.5
  self.healthModifier = 2.0

  self.statModifier = effect.addStatModifierGroup({
    {stat = "protection", effectiveMultiplier = 1},
	{stat = "maxHealth", effectiveMultiplier = 1}
  })
end

function update(dt)
  --Apply the protection
  effect.setStatModifierGroup(self.statModifier, {
    {stat = "protection", effectiveMultiplier = 1 + (self.protectionModifier * status.resourcePercentage("survival_resources_resourceArmour"))},
	{stat = "maxHealth", effectiveMultiplier = 1 + (self.healthModifier * status.resourcePercentage("survival_resources_resourceArmour"))}
  })
end