require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.queryImpactSince = 0 
  self.cooldown = 0 
	
  self.fainted = false
	
  initializeResource()
	
  self.playingCinematic = false
  self.staminaRegen = 0
  self.decayFactor = 100
  
  self.walking = false
  self.exhausted = false
	
  self.firstInterval = false
  self.secondInterval = false
	
  self.foodValueT1 = status.resource("food")
  self.foodValueT2 = status.resource("food")
end

function update(dt)
  self.cooldown = math.floor(self.cooldown, self.cooldown - dt)

  resourceStamina(dt)
  adminDefaults()
	
  shiftrunToggle()
	
  penaltyStatusEffect()
	
  racialBonus()
	
  intervalTimer()
	
  status.setResourcePercentage("survival_resources_resourceStaminaactive", 1.0)	
end

function adminDefaults()
  if player.isAdmin() then
    status.setResourcePercentage("survival_resources_resourceStamina", 1.0)	
    --status.setResourcePercentage("survival_resources_resourceStamina", 0.02)	
  end
end

function initializeResource()
  if status.resourcePercentage("interfaceResourceLogic2") == 1.0 then
    status.setResourcePercentage("survival_resources_resourceStamina", 1.0)
	status.setResourcePercentage("interfaceResourceLogic2", 0.0)		
  end
end

function shiftrunToggle()
  if mcontroller.walking() then
    self.walking = true
  end
		
  if self.walking then
    mcontroller.controlModifiers({runningSuppressed = true})
  elseif not self.walking then
	mcontroller.controlModifiers({runningSuppressed = false})
  end
	
  if mcontroller.jumping() or mcontroller.falling() or mcontroller.crouching() then
    self.walking = false
  end
end

function penaltyStatusEffect()
  if not self.exhausted and self.fainted then
	self.exhausted = true
  end
  if self.exhausted then
    status.addEphemeralEffect("survival_resources_exhausted", 480)	
  end
end

function racialBonus()
  if world.entitySpecies(player.id()) == "apex" then
	status.removeEphemeralEffect("survival_resources_exhausted")
    if (status.resourcePercentage("survival_resources_resourceStamina") <= 0.5) then
	  if self.foodValueT2 ~= self.foodValueT1 then
        self.foodDifference = math.abs(self.foodValueT2 - self.foodValueT1) --Change in hunger is measured to calculate waste production.
	    status.giveResource("survival_resources_resourceStamina", self.foodDifference / 1.5)
      end
	end  	
  end
end

function intervalTimer()
  if not self.firstInterval and not self.secondInterval then
    self.firstInterval = true
	self.secondInterval = false
  elseif self.firstInterval and not self.secondInterval then
    self.firstInterval = false
	self.secondInterval = true
	  
	logResourceValueAtT1()
  elseif not self.firstInterval and self.secondInterval then
	self.firstInterval = true
	self.secondInterval = false
	  
	logResourceValueAtT2()
  end
end

---Resource To Check At First Interval---
function logResourceValueAtT1()
  self.foodValueT1 = status.resource("food")
end
---Resource To Check At Second Interval---
function logResourceValueAtT2()
  self.foodValueT2 = status.resource("food")
end

function resourceStamina(dt)
	
  local impactNotifications, nextStep2 = status.inflictedHitsSince(self.queryImpactSince)
  self.queryImpactSince = nextStep2
  if #impactNotifications > 0 then
	status.overConsumeResource("survival_resources_resourceStamina", 0.01)
  end
	
  --This calculates drain of wakefulness. Should go from full to empty for 3 game days = 1 hour standard.
  -- maths --->> 24 min x 60 = 1440 seconds, 100% / 1440s = 0.0694% used per second as fraction of 100, where 100% = 24min (1 game day)
  -- further, divided, 0.0694 / 3 = 0.023148% used per second, if we assume a 3 day period (1 hour game play) to be 100%
	
  local rotationAngle = 90--util.toDegrees(mcontroller.rotation()) --Do not use as part of set rotation function. Used to override Direction angle.
  local directionAngle = vec2.angle(mcontroller.velocity()) - util.toRadians(90) --Use to set rotation Angle.
  local defaultAngle = util.toRadians(360) * mcontroller.facingDirection()
	
  local movementSpeedSleepRatio = 0.3 + status.resourcePercentage("survival_resources_resourceStamina")
  local movementSpeedSleepRatioTiredCurve = status.resourcePercentage("survival_resources_resourceStamina") - 0.5
  status.setResource("survival_resources_resourceStamina", status.resource("survival_resources_resourceStamina") - (0.023148 * dt))
  	
  -- to do; add movement sleep when walking vs movement speed when running. make running viable until very low sleep,
  --make exhaustion from walking higher than running i.e. the speed modifier is 0.4. make running 0.65 when above say 20 sleep.
	
  if mcontroller.running() and status.resourcePercentage("survival_resources_resourceStamina") > 0.5 then
	mcontroller.controlModifiers({speedModifier = movementSpeedSleepRatio})
  elseif mcontroller.walking() and status.resourcePercentage("survival_resources_resourceStamina") > 0.70 then
	mcontroller.controlModifiers({speedModifier = (movementSpeedSleepRatio - 0.15)}) --run a bit too fast on high stamina. Slow it down a notch.
  elseif mcontroller.walking() and status.resourcePercentage("survival_resources_resourceStamina") > 0.5 and status.resourcePercentage("survival_resources_resourceStamina") <= 0.70 then
	mcontroller.controlModifiers({speedModifier = (movementSpeedSleepRatio)})
  elseif mcontroller.running() and status.resourcePercentage("survival_resources_resourceStamina") <= 0.5 then
	mcontroller.controlModifiers({speedModifier = movementSpeedSleepRatio + (movementSpeedSleepRatioTiredCurve * -1)})
  elseif mcontroller.walking() and status.resourcePercentage("survival_resources_resourceStamina") <= 0.5 then
	mcontroller.controlModifiers({speedModifier = movementSpeedSleepRatio + (movementSpeedSleepRatioTiredCurve * -1)})
  end
	
  --if mcontroller.walking() and not self.fainted and mcontroller.groundMovement() and not (status.resourcePercentage("survival_resources_resourceStamina") <= 0.0) then
  if not self.fainted and mcontroller.groundMovement() and not status.resourceLocked("survival_resources_resourceStamina") then
    --status.overConsumeResource("survival_resources_resourceStamina", 0.005)
		
	status.setResourcePercentage("survival_resources_resourceStamina", status.resourcePercentage("survival_resources_resourceStamina") - self.staminaRegen)
	self.staminaRegen = (dt / 100) / self.decayFactor
  elseif player.isLounging() then
	status.setResourcePercentage("survival_resources_resourceStamina", status.resourcePercentage("survival_resources_resourceStamina") + self.staminaRegen)
	self.staminaRegen = (dt / 100) / 2
	status.removeEphemeralEffect("survival_resources_exhausted")
	self.exhausted = false
  end
  
  if (status.resourcePercentage("survival_resources_resourceStamina") <= 0.0) then
    self.fainted = true
	
	if not self.playingCinematic and self.fainted then
      self.playingCinematic = true
	  player.playCinematic("/cinematics/survival_resources_blackout.cinematic", false)
    end
		
    if (status.resourcePercentage("breath") <= 0.3) then
	  status.setResourcePercentage("breath", 0.3)
	end
		
    if mcontroller.liquidMovement() then
	  status.giveResource("survival_resources_resourceStamina", 0.025)
	else
	  status.giveResource("survival_resources_resourceStamina", 0.01)	
	end
		
	if mcontroller.facingDirection() == -1 then
      mcontroller.setRotation(util.toRadians(75))
	elseif mcontroller.facingDirection() == 1 then
	  mcontroller.setRotation(util.toRadians(-75))	
	end
		
	mcontroller.controlParameters({
	  gravityMultiplier = 3.0,
	  liquidBuoyancy = 0.95,
	  airFriction = 3.5,
	  airForce = 10,
	  collisionPoly = {{0,-2}},
	  standingPoly = {{0,-2}},
	  crouchingPoly = {{0,-2}},
	  collisionEnabled = true
    })
    mcontroller.controlModifiers({
      facingSuppressed = true,
      movementSuppressed = true,
	  jumpingSuppressed = true
    })
		
	mcontroller.setXVelocity(0)
		
	if mcontroller.yVelocity() > 0 then
	  mcontroller.setYVelocity(0)
	elseif mcontroller.yVelocity() < 0 and not mcontroller.groundMovement() and not mcontroller.liquidMovement() then
	  --mcontroller.controlApproachYVelocity(-10, 10)
	end
		
  elseif (status.resourcePercentage("survival_resources_resourceStamina") >= 0.0) and (status.resourcePercentage("survival_resources_resourceStamina") <= 0.35) and self.fainted then
	
    if (status.resourcePercentage("breath") <= 0.3) then
	  status.setResourcePercentage("breath", 0.3)
	end

    if mcontroller.liquidMovement() then
	  status.setResourcePercentage("survival_resources_resourceStamina", status.resourcePercentage("survival_resources_resourceStamina") + (dt / 100))
	else
	  status.setResourcePercentage("survival_resources_resourceStamina", status.resourcePercentage("survival_resources_resourceStamina") + (dt / 100))	
	end
		
	if mcontroller.facingDirection() == -1 then
      mcontroller.setRotation(util.toRadians(75))
	elseif mcontroller.facingDirection() == 1 then
	  mcontroller.setRotation(util.toRadians(-75))	
	end
	
	mcontroller.controlParameters({
	  gravityMultiplier = 0.0,
	  liquidBuoyancy = 0.65,
	  airFriction = 3.5,
	  airForce = 10,
	  collisionPoly = {{0,-2}},
	  standingPoly = {{0,-2}},
	  crouchingPoly = {{0,-2}},
	  collisionEnabled = true
    })
    mcontroller.controlModifiers({
      facingSuppressed = true,
      movementSuppressed = true,
	  jumpingSuppressed = true
    })
		
	mcontroller.setXVelocity(0)
		
	if mcontroller.yVelocity() > 0 then
	  mcontroller.setYVelocity(0)
	elseif mcontroller.yVelocity() < 0 and not mcontroller.groundMovement() and not mcontroller.liquidMovement() then
	  --mcontroller.controlApproachYVelocity(-10, 10)
	elseif mcontroller.yVelocity() < 0 and not mcontroller.groundMovement() and mcontroller.liquidMovement() then
		mcontroller.controlApproachYVelocity(-10, 10)	
	end
		
  elseif (status.resourcePercentage("survival_resources_resourceStamina") > 0.35) then
	mcontroller.setRotation(0)
      mcontroller.controlParameters({
	  collisionEnabled = true
    })
    self.fainted = false
	self.playingCinematic = false
  end

  if self.fainted then
	status.setResourceLocked("survival_resources_resourceStamina", true)
  else
    status.setResourceLocked("survival_resources_resourceStamina", false)	
  end
end

function uninit()
	
end