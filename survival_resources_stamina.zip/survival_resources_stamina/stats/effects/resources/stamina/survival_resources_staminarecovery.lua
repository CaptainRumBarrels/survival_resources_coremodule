function init()
  
end

function update(dt)
  if status.resourcePercentage("survival_resources_resourceStamina") < 1.0 then
    status.setResource("survival_resources_resourceStamina", status.resource("survival_resources_resourceStamina") + 0.01)
  end
end

function uninit()
  
end
