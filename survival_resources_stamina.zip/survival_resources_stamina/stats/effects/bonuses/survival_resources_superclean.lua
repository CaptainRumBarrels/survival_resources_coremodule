require "/scripts/util.lua"

function init()

end

function update()  
  status.setResourcePercentage("survival_resources_resourceHygiene", 0.99)
  status.removeEphemeralEffect("survival_resources_soiled1")
  status.removeEphemeralEffect("survival_resources_soiled2")
  status.removeEphemeralEffect("survival_resources_soiled3")
  status.removeEphemeralEffect("survival_resources_soiled4")
	
  if not self.statImmunityApplied then
    self.statModifier = effect.addStatModifierGroup({
	  {stat = "poisonResistance", amount = 0.15}
      {stat = "poisonStatusImmunity", amount = 1},
	  {stat = "fireResistance", amount = 0.15},
	  {stat = "fireStatusImmunity", amount = 1},
				
      {stat = "tarImmunity", amount = 1},
      {stat = "tarStatusImmunity", amount = 1},
      {stat = "slimeImmunity", amount = 1}
    })
    self.statImmunityApplied = true
  end
end

function onExpire()
  effect.removeStatModifierGroup(self.statModifier)
  self.statImmunityApplied = false
  status.setResourcePercentage("survival_resources_resourceHygiene", 0.4)
end

function uninit()

end