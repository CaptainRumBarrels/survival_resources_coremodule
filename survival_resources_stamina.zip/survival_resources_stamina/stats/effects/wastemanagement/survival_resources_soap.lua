function init()
  script.setUpdateDelta(15) -- 60 is 1 second. Updates every frame. 6 frames will give 10 points over 1 second. 12, 10 points 2 seconds, 24, 4 seconds
end

function update(dt)
  if (status.resourcePercentage("survival_resources_resourceHygiene") <= 1.0) then
    status.giveResource("survival_resources_resourceHygiene", 1)
  end
  if (status.resourcePercentage("survival_resources_resourceHygiene") >= 1.0) then
    status.addEphemeralEffect("survival_resources_superclean", 480)
  end  
end

function uninit()
  
end