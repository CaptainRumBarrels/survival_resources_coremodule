survival_resources_staminabuff1 = WeaponAbility:new()

function survival_resources_staminabuff1:init()
  self.coolDown = 0
  self.abilityCooldown = 3
  self.resourceConsumptionTimer = 0
  self.active = false
end

function survival_resources_staminabuff1:update(dt, fireMode, shiftHeld)
  WeaponAbility.update(self, dt, fireMode, shiftHeld)	
  self.coolDown = math.max(0, self.coolDown - dt)
	
  if self.fireMode == "alt" and self.lastFireMode ~= "alt" and not status.resourceLocked("survival_resources_resourceStamina") then
	if not self.active and (self.coolDown <= 0) then
	  self.active = true
	elseif self.active then
	  self.active = false
	  self.coolDown = self.abilityCooldown
	end
  end
  self.lastFireMode = fireMode
	
  if self.active and not status.resourceLocked("survival_resources_resourceStamina") then
	status.overConsumeResource("survival_resources_resourceStamina", 0.005)
	status.addEphemeralEffect("rage", 5)
  elseif not self.active then
	status.removeEphemeralEffect("rage")
  end
	
  if status.resourceLocked("survival_resources_resourceStamina") then
    self.active = false	
  end
end

function survival_resources_staminabuff1:uninit()
  
end
