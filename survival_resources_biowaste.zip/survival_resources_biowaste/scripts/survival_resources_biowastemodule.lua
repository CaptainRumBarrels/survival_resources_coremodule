require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.firstInterval = false
  self.secondInterval = false
	
  self.resourceStartTime = 0
  self.resourceTimer = 0
	
  self.foodValueT1 = status.resource("food")
  self.foodValueT2 = status.resource("food")
	
  self.biowasteValueT1 = status.resource("survival_resources_resourceBiowaste")	
  self.biowasteValueT2 = status.resource("survival_resources_resourceBiowaste")
	
  self.biowaste2ValueT1 = status.resource("survival_resources_resourceBiowaste2")
  self.biowaste2ValueT2 = status.resource("survival_resources_resourceBiowaste2")
	
  self.wasteAccidentOccured = false
  self.wasteAccidentTimer = 0
  self.minWasteAccidentRandInterval = 5
  self.maxWasteAccidentRandInterval = 120
  self.wasteAccidentIntervalRand = math.random(self.minWasteAccidentRandInterval, self.maxWasteAccidentRandInterval)
	
  self.waste2AccidentOccured = false
  self.waste2AccidentTimer = 0
  self.minWaste2AccidentRandInterval = 5
  self.maxWaste2AccidentRandInterval = 15
  self.waste2AccidentIntervalRand = math.random(self.minWaste2AccidentRandInterval, self.maxWaste2AccidentRandInterval)
	
  self.isWaste2Standing = false
  self.isWaste2Crouching = false
	
  self.wasteFullTimer = 10
  self.wasteFullMaxTime = 100
	
  if status.resourcePercentage("interfaceResourceLogic2") == 1.0 then
	status.setResourcePercentage("survival_resources_resourceBiowaste", 0.0)
	status.setResourcePercentage("survival_resources_resourceBiowaste2", 0.0)

	status.setResourcePercentage("interfaceResourceLogic2", 0.0)
  end
end

function update(dt)
  self.resourceTimer = math.floor(self.resourceStartTime, self.resourceTimer + dt)
	
  intervalTimer()
	
  resourceBiowaste(dt)
  resourceHygiene()

  adminDefaults()
	
  racialBonus()
  getSample()
	
  status.setResourcePercentage("survival_resources_resourceBiowasteactive", 1.0)
end

function adminDefaults()
  if player.isAdmin() then
    --status.setResourcePercentage("survival_resources_resourceBiowaste", 0.95) --	FOR DEV TESTING UNCOMMENT AND WILL FILL BAR BY DEFAULT
    --status.setResourcePercentage("survival_resources_resourceBiowaste2", 0.95)	
    status.setResourcePercentage("survival_resources_resourceBiowaste", 0.0)	
    status.setResourcePercentage("survival_resources_resourceBiowaste2", 0.0)	
		
    status.removeEphemeralEffect("survival_resources_soiled1")
    status.removeEphemeralEffect("survival_resources_soiled2")
    status.removeEphemeralEffect("survival_resources_soiled3")
    status.removeEphemeralEffect("survival_resources_soiled4")
  end
end

function intervalTimer()
  if not self.firstInterval and not self.secondInterval then
    self.firstInterval = true
	self.secondInterval = false
  elseif self.firstInterval and not self.secondInterval then
    self.firstInterval = false
	self.secondInterval = true
	  
	logResourceValueAtT1()
  elseif not self.firstInterval and self.secondInterval then
	self.firstInterval = true
	self.secondInterval = false
	  
	logResourceValueAtT2()
  end
end

---Resource To Check At First Interval---
function logResourceValueAtT1()

  self.foodValueT1 = status.resource("food")
  self.biowasteValueT1 = status.resource("survival_resources_resourceBiowaste")
  self.biowaste2ValueT1 = status.resource("survival_resources_resourceBiowaste2")
end
---Resource To Check At Second Interval---
function logResourceValueAtT2()    

  self.foodValueT2 = status.resource("food")
  self.biowasteValueT2 = status.resource("survival_resources_resourceBiowaste")
  self.biowaste2ValueT2 = status.resource("survival_resources_resourceBiowaste2")
end

function resourceBiowaste(dt)
  if self.foodValueT2 ~= self.foodValueT1 then
    self.foodDifference = math.abs(self.foodValueT2 - self.foodValueT1) --Change in hunger is measured to calculate waste production.
	self.biowasteDifference = math.abs(self.biowasteValueT1 - self.biowasteValueT2) -- This is calculating difference in waste produced at T1 and T2.
	self.biowaste2Difference = math.abs(self.biowaste2ValueT1 - self.biowaste2ValueT2)	
	--Give player biowaste when they eat. 
	status.giveResource("survival_resources_resourceBiowaste", self.foodDifference / 2)
	status.giveResource("survival_resources_resourceBiowaste2", self.foodDifference / 4) -- Obviosuly not equal to food value.
	if self.biowasteDifference >= 14 then
	  status.addEphemeralEffect("colorred", 0.1)
	  status.overConsumeResource("health", 2)
	  --animator.playSound("ouch")
    end
  end
  -- Give player passive amounts of biowaste.
  status.giveResource("survival_resources_resourceBiowaste", 0.0583 * self.resourceTimer)  -- This is the Food Delta Value from the Player.Config.
  status.giveResource("survival_resources_resourceBiowaste2", 0.0583 * self.resourceTimer)
  
  if (status.resourcePercentage("survival_resources_resourceBiowaste") >= 1.0) then
    self.wasteAccidentTimer = self.wasteAccidentTimer + script.updateDt()
	if (self.wasteAccidentTimer >= self.wasteAccidentIntervalRand) then
	  self.wasteAccidentIntervalRand = math.random(self.minWasteAccidentRandInterval, self.maxWasteAccidentRandInterval)
      --self.wasteAccidentOccured = true
      status.addEphemeralEffect("survival_resources_makewaste", 0.5)
	  status.addEphemeralEffect("colorred", 0.1)
	  status.overConsumeResource("health", math.random(8, 15))
	  status.overConsumeResource("survival_resources_resourceBiowaste", math.random(35, 75))
      status.setResourcePercentage("survival_resources_resourceHygiene", 0.39)
	  status.addEphemeralEffect("survival_resources_soiled1")
	  --animator.playSound("ouch")
	  --world.spawnProjectile("survival_resources_biowaste", entity.position(), entity.id(), {0.0,0.0}, false)
	  --world.placeMaterial(entity.position(), "foreground", "sewage", 5, true) --turn this into spawn projectile to not require placable surfaces.
      self.wasteAccidentTimer = 0
	end
	if mcontroller.crouching() then
	  status.addEphemeralEffect("survival_resources_makewaste", 0.5)
	  status.overConsumeResource("survival_resources_resourceBiowaste", math.random(20, 35))
	end
  end
	
  if (status.resourcePercentage("survival_resources_resourceBiowaste2") >= 1.0) then
    self.waste2AccidentTimer = self.waste2AccidentTimer + script.updateDt()
	if (self.waste2AccidentTimer >= self.waste2AccidentIntervalRand) then
	  self.waste2AccidentIntervalRand = math.random(self.minWaste2AccidentRandInterval, self.maxWaste2AccidentRandInterval)
      self.waste2AccidentOccured = true
	  if not mcontroller.crouching() then
        status.addEphemeralEffect("survival_resources_makewaste2", (self.waste2AccidentIntervalRand / 4))
		status.addEphemeralEffect("survival_resources_soiled1")
		status.setResourcePercentage("survival_resources_resourceHygiene", 0.39)
        self.waste2AccidentTimer = 0
	  end
	end
  end
  if (status.resourcePercentage("survival_resources_resourceBiowaste2") >= 0.9) and (status.resourcePercentage("survival_resources_resourceBiowaste2") <= 1.0) then
	if (self.waste2AccidentTimer < self.waste2AccidentIntervalRand) then
	  if mcontroller.crouching() then
	    status.addEphemeralEffect("survival_resources_makewaste2", 5)
		self.waste2AccidentTimer = 0
	  elseif not mcontroller.crouching() and not self.waste2AccidentOccured then
		if (self.waste2AccidentTimer <= 0) then
		  status.removeEphemeralEffect("survival_resources_makewaste2")
		  self.waste2AccidentOccured = false
		end
	  end
	end
  end
end

function resourceHygiene()
  local delta = 0.0125 -- 0.0125 X 80fps script delta = 1 point over 1 second.
  local timePeriod = 240 -- seconds; 4 minutes. 10 points will be consumed over 10 minutes.
  if (status.resourcePercentage("survival_resources_resourceHygiene") < 0.4) then
	status.overConsumeResource("survival_resources_resourceHygiene", (delta / timePeriod)) 	
  end
  if (status.resourcePercentage("survival_resources_resourceHygiene") >= 1.0) then
	status.setResourcePercentage("survival_resources_resourceHygiene", 0.4)
	--status.addEphemeralEffect("survival_resources_superclean")	
  end
  if (status.resourcePercentage("survival_resources_resourceHygiene") >= 0.4) then
    status.removeEphemeralEffect("survival_resources_soiled1")
    status.removeEphemeralEffect("survival_resources_soiled2")
	status.removeEphemeralEffect("survival_resources_soiled3")
	status.removeEphemeralEffect("survival_resources_soiled4")
  end
	
  if (status.resourcePercentage("survival_resources_resourceHygiene") < 0.4)
  and (status.resourcePercentage("survival_resources_resourceHygiene") > 0.3) then
    status.addEphemeralEffect("survival_resources_soiled1")		
	status.removeEphemeralEffect("survival_resources_soiled2")
	status.removeEphemeralEffect("survival_resources_soiled3")
	status.removeEphemeralEffect("survival_resources_soiled4")	
	
  elseif (status.resourcePercentage("survival_resources_resourceHygiene") <= 0.3)
  and (status.resourcePercentage("survival_resources_resourceHygiene") > 0.2) then
    status.addEphemeralEffect("survival_resources_soiled2")	
	status.removeEphemeralEffect("survival_resources_soiled1")
	status.removeEphemeralEffect("survival_resources_soiled3")
	status.removeEphemeralEffect("survival_resources_soiled4")
		
  elseif (status.resourcePercentage("survival_resources_resourceHygiene") <= 0.2)
  and (status.resourcePercentage("survival_resources_resourceHygiene") > 0.1) then
	status.addEphemeralEffect("survival_resources_soiled3")			
	status.removeEphemeralEffect("survival_resources_soiled1")
	status.removeEphemeralEffect("survival_resources_soiled2")
	status.removeEphemeralEffect("survival_resources_soiled4")
		
  elseif (status.resourcePercentage("survival_resources_resourceHygiene") <= 0.1) then
	status.addEphemeralEffect("survival_resources_soiled4")		
	status.removeEphemeralEffect("survival_resources_soiled1")
	status.removeEphemeralEffect("survival_resources_soiled2")
	status.removeEphemeralEffect("survival_resources_soiled3")	
		
  end
end

function getSample()
  local sample = world.lightLevel(mcontroller.position())
  return math.floor(sample * 1000) * 0.1
end

function racialBonus()
  local sample = getSample()
  if sample >= 40 then
		
    if world.entitySpecies(player.id()) == "floran" then
	  if (status.resourcePercentage("survival_resources_resourceBiowaste") <= 0.0) and (status.resourcePercentage("survival_resources_resourceBiowaste2") <= 0.0) then
		status.addEphemeralEffect("thorns", 120)
	  end
			
	  if mcontroller.groundMovement() and not mcontroller.running() and not mcontroller.walking() then
	    if (status.resourcePercentage("survival_resources_resourceBiowaste") >= 0.35) then
	      status.overConsumeResource("survival_resources_resourceBiowaste", 0.015)
		  status.giveResource("health", 0.05)
	    end
	    if (status.resourcePercentage("survival_resources_resourceBiowaste2") >= 0.35) then
	      status.overConsumeResource("survival_resources_resourceBiowaste2", 0.015)
		  status.giveResource("health", 0.05)
	    end	
	  end		
	end
		
  end
end

function uninit()
	
end