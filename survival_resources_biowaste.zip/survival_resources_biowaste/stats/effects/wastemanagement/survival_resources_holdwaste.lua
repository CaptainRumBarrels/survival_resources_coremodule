function init()
  self.logValue = false
  self.resourceValue = status.resourcePercentage(self.resource)
  self.resource = "survival_resources_resourceBiowaste"
end

function update(dt)
  self.resourceTimer = math.floor(self.resourceStartTime, self.resourceTimer + dt)
  status.overConsumeResource("survival_resources_resourceBiowaste", 0.0583 * self.resourceTimer)
  if not self.logValue then
	self.resourceValue = self.resourceValue
	self.logValue = true
	status.setResource("hunger", 1.0)
  end
  status.setResource(self.resourceValue, self.resourceValue)
end

function uninit()
  self.logValue = false
end