function init()
  --animator.setParticleEmitterOffsetRegion("drips", mcontroller.boundBox())
  --animator.setParticleEmitterActive("drips", true)
  effect.setParentDirectives("fade=505000=0.6")
  effect.addStatModifierGroup({
    {stat = "jumpModifier", amount = -0.15}
  })
end

function update(dt)
  mcontroller.controlModifiers({
      speedModifier = 0.8,
      airJumpModifier = 0.85
    })
	
  status.giveResource("survival_resources_resourceBiowaste", 0.0005)  -- This is the Food Delta Value from the Player.Config.
  status.giveResource("survival_resources_resourceBiowaste2", 0.0005)
	
  if (status.resourcePercentage("health") >= 0.7) then
	status.setResourcePercentage("health", 0.7)
  end
  if (status.resourcePercentage("survival_resources_resourceStamina") >= 0.7) then
	status.setResourcePercentage("survival_resources_resourceStamina", 0.7)
  end
end

function onExpire()

end	
	
function uninit()
  
end
