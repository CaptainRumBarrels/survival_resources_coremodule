require "/scripts/vec2.lua"

function init()
  self.detectWallArea = config.getParameter("wallPositions")
  self.detectDrainArea = config.getParameter("drainPositions") 
  self.damageWallArea = config.getParameter("wallPositions")
	
  self.detectFloorArea = config.getParameter("subFloorPositions")
  self.damageFloorArea = config.getParameter("subFloorPositions")
	
  self.door1Position = config.getParameter("door1")
	
  self.showerPosition = config.getParameter("shower")
  self.toiletPosition = config.getParameter("toilet")
  self.biocyclerPosition = config.getParameter("biocycler")
  self.arcanebenchPosition = config.getParameter("arcanebench")
  self.o2TankPosition = config.getParameter("o2tank")
  self.fabricatorPosition = config.getParameter("fabricator")
  self.fabricatorTopPosition = config.getParameter("fabricatortop")
  self.lockerPosition = config.getParameter("bunkerlocker")
	
  self.showerPlaced = false
  self.toiletPlaced = false
  self.arcanebenchPlaced = false
  self.o2TankPlaced = false
  self.farbricatorPlaced = false
  self.farbricatorTopPlaced = false
  self.biocyclerPlaced = false
  self.door1Placed = false
  self.lockerPlaced = false
	
  self.tileProtected = false
end

function update(dt)
  local lightAngleRight = 315
  local lightAngleLeft = 225
  local lightAngleCeiling = 270
  animator.setLightPointAngle("light1", lightAngleLeft)
  animator.setLightPointAngle("light2", lightAngleRight)
  animator.setLightPointAngle("light3", lightAngleCeiling)
  animator.setLightPointAngle("light4", lightAngleCeiling)
	
  spawnWall()
  drain()
  spawnSubFloor()
  placeObects()
	
  if #self.detectDrainArea > 0 then
    for _, drainPosition in ipairs(self.detectDrainArea) do
      drainPosition = vec2.add(drainPosition, entity.position())
      world.debugPoint(drainPosition, "yellow")
    end
  end
	
end

-- Removes Liquids at current position
function drain()
  if #self.detectDrainArea > 0 then
    for _, drainPosition in ipairs(self.detectDrainArea) do
      drainPosition = vec2.add(drainPosition, entity.position())
	  if world.liquidAt(drainPosition) then
        world.forceDestroyLiquid(drainPosition)
      end
	end
  end
end
	
function spawnWall()
  if #self.detectWallArea > 0 then
    for _, wallPosition in ipairs(self.detectWallArea) do
      wallPosition = vec2.add(wallPosition, entity.position())
	  world.placeMaterial(wallPosition, "background", "survival_resources_hubwall", 0, true)
	end
  end
end

function spawnSubFloor()
  for _, floorPosition in ipairs(self.detectFloorArea) do
    floorPosition = vec2.add(floorPosition, entity.position())
	local dungeonID = world.dungeonId(floorPosition)
	world.setTileProtection(dungeonID, false)
  end
end

function placeObects()
  if not self.door1Placed then
    for _, door1Position in ipairs(self.door1Position) do
      door1Position = vec2.add(door1Position, entity.position())
	  world.placeObject("survival_resources_bunkerdoor", door1Position, 1)
    end
	self.door1Placed = true
  end	

  if not self.showerPlaced then
    for _, showerPosition in ipairs(self.showerPosition) do
      showerPosition = vec2.add(showerPosition, entity.position())
	  world.placeObject("survival_resources_shower2", showerPosition, -1)
    end
	self.showerPlaced = true
  end
	
  if not self.toiletPlaced then
    for _, toiletPosition in ipairs(self.toiletPosition) do
      toiletPosition = vec2.add(toiletPosition, entity.position())
      world.placeObject("survival_resources_bathroomstall2", toiletPosition, -1)
    end
	self.toiletPlaced = true
  end
	
  if not self.arcanebenchPlaced then
    for _, arcanebenchPosition in ipairs(self.arcanebenchPosition) do
      arcanebenchPosition = vec2.add(arcanebenchPosition, entity.position())
      world.placeObject("survival_resources_arcanistbench2", arcanebenchPosition, -1)
    end
	self.arcanebenchPlaced = true
  end

  --objects to be placed in sequence
  if not self.biocyclerPlaced then
    for _, biocyclerPosition in ipairs(self.biocyclerPosition) do
      biocyclerPosition = vec2.add(biocyclerPosition, entity.position())
      world.placeObject("survival_resources_biocycler2", biocyclerPosition, -1)
    end
	self.biocyclerPlaced = true
  end
	
  if not self.fabricatorPlaced and self.biocyclerPlaced then
    for _, fabricatorPosition in ipairs(self.fabricatorPosition) do
      fabricatorPosition = vec2.add(fabricatorPosition, entity.position())
      world.placeObject("survival_resources_fabricator2", fabricatorPosition, -1)
    end
	self.fabricatorPlaced = true
  end
	
  if not self.fabricatorTopPlaced and self.fabricatorPlaced then
    for _, fabricatorTopPosition in ipairs(self.fabricatorTopPosition) do
      fabricatorTopPosition = vec2.add(fabricatorTopPosition, entity.position())
      world.placeObject("survival_resources_fabricatortop", fabricatorTopPosition, -1)
    end
	self.fabricatorTopPlaced = true
  end
	
  if not self.o2TankPlaced and self.fabricatorTopPlaced then
    for _, o2TankPosition in ipairs(self.o2TankPosition) do
      o2TankPosition = vec2.add(o2TankPosition, entity.position())
      world.placeObject("survival_resources_oxygengenerator2", o2TankPosition, -1)
    end
	self.o2TankPlaced = true
  end
	
  if not self.lockerPlaced then
    for _, lockerPosition in ipairs(self.lockerPosition) do
      lockerPosition = vec2.add(lockerPosition, entity.position())
      world.placeObject("survival_resources_bunkerlocker", lockerPosition, -1)
    end
	self.lockerPlaced = true
  end
end

function die(smash)
  if #self.damageWallArea > 0 then
    for _, damageWallPosition in ipairs(self.damageWallArea) do
      damageWallPosition = vec2.add(damageWallPosition, entity.position())
	  if world.material(damageWallPosition, "background") == "survival_resources_hubwall" then
	    world.damageTileArea(damageWallPosition, 0.8, "background", damageWallPosition, "blockish", 10000, 0)
	  end
	end
  end
	
  if #self.damageFloorArea > 0 then
    for _, damageFloorPosition in ipairs(self.damageFloorArea) do
      damageFloorPosition = vec2.add(damageFloorPosition, entity.position())
	  local dungeonID = world.dungeonId(damageFloorPosition)
	  world.setTileProtection(dungeonID, false)
	end
  end  
end

function uninit()
  
end
