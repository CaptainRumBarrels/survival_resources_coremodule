function init()
  
end

function update()

  local itemCount = player.hasCountOfItem("survival_resources_hydroxpack")
	
  world.spawnItem("survival_resources_hydrogenfuel", entity.position(), itemCount)
  world.spawnItem("survival_resources_oxygenboost", entity.position(), itemCount)

  item.consume(itemCount)
end

function uninit()

end
