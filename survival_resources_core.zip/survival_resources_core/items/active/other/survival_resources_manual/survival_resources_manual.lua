function init()
  status.resetResource("interfaceResourceLogic4")
end

function activate(fireMode, shiftHeld)
  if status.resourcePercentage("interfaceResourceLogic4") == 0.0 then
    activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
	status.setResource("interfaceResourceLogic4", 1)
  end
  --activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
end

function uninit()
  status.resetResource("interfaceResourceLogic4")
end
