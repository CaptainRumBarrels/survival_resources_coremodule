require "/scripts/messageutil.lua"
require "/scripts/util.lua"

function init()
  sb.logInfo("-----Survival Utility Initialising...-----")
  
  ---Entity Messaging Initialisation---
  message.setHandler("checkPlayerHasItem", localHandler(checkPlayerHasItem))
  message.setHandler("playerEatYourItem", localHandler(playerEatYourItem))
  
  sb.logInfo("-----Survival Utility Initialised!-----")
end

function update(dt)
end

---Entity Messaging Handler---
--Item Checking
function checkPlayerHasItem(itemDescriptor)
  return player.hasItem(itemDescriptor)
end
--Item Consumption
function playerEatYourItem(itemDescriptor)
  return player.consumeItem(itemDescriptor)
end
