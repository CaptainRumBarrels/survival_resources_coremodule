require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
	
  sb.logInfo("-----Survival Artificial Resource Initialising...-----")
	
  ---Artificial Resources Initialisation---
  self.mouthPosition = status.statusProperty("mouthPosition") or {0,0}
  self.mouthBounds = {self.mouthPosition[1], self.mouthPosition[2], self.mouthPosition[1], self.mouthPosition[2]}

  ---Resource Dynamics Startup---
  self.energyRegen = status.resourcePercentage("energy")
  self.queryImpactSince = 0 
	
  sb.logInfo("-----Survival Artificial Resource Initialised!-----")
end

function update(dt)
  local impactNotifications, nextStep2 = status.inflictedHitsSince(self.queryImpactSince)
  self.queryImpactSince = nextStep2	

  adminDefaults()	
  --Resource Dynamics
  resourceSpecialPower(dt)
  resourceEnergy(dt)
  resourceOxygen()

  correctPosition()
	
  if world.entitySpecies(player.id()) == "hylotl" then
    if #impactNotifications > 0 then
	  if (status.resourcePercentage("energy") <= 0.5) then
	    status.giveResource("energy", 1.5)
	  end
	end
  end
end

function adminDefaults()
  if player.isAdmin() then
    status.setResourcePercentage("survival_resources_resourceSpecial", 1.0)
    status.setResourcePercentage("breath", 1.0)
		
	--if (status.resourcePercentage("survival_resources_resourceStaminaactive") == 0.0) then
	 -- status.setResourcePercentage("survival_resources_resourceStamina", 0.0)
	--end
	--if (status.resourcePercentage("survival_resources_resourceManaaactive") == 0.0) then
	  --status.setResourcePercentage("survival_resources_resourceMana", 0.0)
	--end
	--if (status.resourcePercentage("survival_resources_resourceArmouraactive") == 0.0) then
	 -- status.setResourcePercentage("survival_resources_resourceArmour", 0.0)
	--end
	--if (status.resourcePercentage("survival_resources_resourceAmmoactive") == 0.0) then
	  --status.setResourcePercentage("survival_resources_resourceAmmo", 0.0)
	  --status.setResourcePercentage("survival_resources_resourceAmmoMax", 0.0)
	--end
	--if (status.resourcePercentage("survival_resources_resourceBiowasteactive") == 0.0) then
	  --status.setResourcePercentage("survival_resources_resourceBiowaste", 0.0)
	  --status.setResourcePercentage("survival_resources_resourceBiowaste2", 0.0)
	--end
  end
end

function resourceSpecialPower(dt)
  if world.entitySpecies(player.id()) == "human" then
    status.setResource("survival_resources_resourceSpecial", status.resource("survival_resources_resourceSpecial") + (0.06 * dt)) -- 100% / 60sec / 10min / 2 to regain 100% in 20min
  else
	status.setResource("survival_resources_resourceSpecial", status.resource("survival_resources_resourceSpecial") + (0.03 * dt)) -- 100% / 60sec / 10min / 2 to regain 100% in 20min
  end
end

function resourceOxygen()
  local position = mcontroller.position()
  local worldMouthPosition = {
    self.mouthPosition[1] + position[1],
    self.mouthPosition[2] + position[2]
  }

  local liquidAtMouth = world.liquidAt(worldMouthPosition)
  local airAtMouth = world.breathable(worldMouthPosition)
  if liquidAtMouth and (liquidAtMouth[1] == 1 or liquidAtMouth[1] == 2) then
    if status.resourcePercentage("breath") >= 0.95 then
	  status.overConsumeResource("breath", 0.3)
	else
	  status.overConsumeResource("breath", 0.1685)
	end
  elseif not airAtMouth then
    if status.resourcePercentage("breath") >= 0.95 then
	  status.overConsumeResource("breath", 0.3)
	else
	  status.overConsumeResource("breath", 0.1685)
	end
  else
  
  end  
end

function resourceEnergy(dt)
  if not status.resourceLocked("energy") and status.resourcePercentage("energy") >= 0.01 then
    status.overConsumeResource("energy", 0.0001)
	status.giveResource("energy", 0.0001)
  end
  if status.resourceLocked("energy") then
    --status.resource("energy", status.resourcePercentage("energy") - 0.575) -- Used to slow hardcoded recharge. Wearing armour increases the recharge. Attempting to make recharge with no flux in time.
    status.setResource("energy", status.resource("energy") - 0.93) -- Used to slow hardcoded recharge. Wearing armour increases the recharge. Attempting to make recharge with no flux in time.
  end
    --status.setResourcePercentage("energy", 0)
	--self.energyRegen = self.energyRegen + dt / 50
  --elseif not status.resourceLocked("energy") then
	--self.energyRegen = 0
  --end
  if status.resourcePercentage("energy") >= 0.98 then
    status.setResourcePercentage("energy", 1.0)
	status.setResourceLocked("energy", false)
  end
end

function correctPosition()
  if mcontroller.isCollisionStuck() then
    -- sloppy catch-all correction for various cases of getting stuck in things
    -- due to bad spawn position, failure to exit loungeable (on ships), etc.
    local poly = mcontroller.collisionPoly()
    local pos = mcontroller.position()
    for maxDist = 4, 8 do
      local resolvePos = world.resolvePolyCollision(poly, pos, maxDist)
      if resolvePos then
        mcontroller.setPosition(resolvePos)
        break
      end
    end
  end
end