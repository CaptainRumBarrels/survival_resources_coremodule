require "/scripts/util.lua"

function init()
  self.required = 100

  update()
  status.setResourcePercentage("interfaceResourceLogic4", 0.0)
end

function update(dt)
  resourceSpecial()
   
  --status.addEphemeralEffect("glow", 5)
  --if (status.resourcePercentage("interfaceResourceLogic4") == 1.0) then
  --if self.close then
	--pane.dismiss()
	--close()
  --end
end


function resourceSpecial()
  local resourceSpecial = status.resourcePercentage("survival_resources_resourceSpecial") * 100
  widget.setText("resourceSpecialLabel", math.floor(string.format("%s", resourceSpecial)))
  widget.setFontColor("resourceSpecialLabel", resourceSpecial >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceSpecialBar", resourceSpecial / 100)
end

function uninit()
  status.setResourcePercentage("interfaceResourceLogic4", 1.0)
end