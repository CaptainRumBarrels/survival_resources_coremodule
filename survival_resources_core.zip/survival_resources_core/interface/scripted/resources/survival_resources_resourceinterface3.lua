require "/scripts/util.lua"

function init()
  self.required = 100

  update()
  status.setResourcePercentage("interfaceResourceLogic1", 0.0)
end

function update(dt)
  resourceHealth()
  resourceHunger()
  resourceBiowaste()
  resourceStamina()
  
  resourceEnergy()
  resourceMana()
  resourceArmour()
	
  resourceAmmo()
  resourceSpecial()
	
  resourceBreath()
	
  --if (status.resourcePercentage("interfaceResourceLogic4") == 1.0) then
end

function resourceHealth()
  local resourceHealth = status.resourcePercentage("health") * 100
  widget.setText("resourceHealthLabel", math.floor(string.format("%s", resourceHealth)))
  widget.setFontColor("resourceHealthLabel", resourceHealth >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceHealthBar", resourceHealth / 100)
end

function resourceHunger()
  local resourceHunger = status.resourcePercentage("food") * 100
  widget.setText("resourceHungerLabel", math.floor(string.format("%s", resourceHunger)))
  widget.setFontColor("resourceHungerLabel", resourceHunger >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceHungerBar", resourceHunger / 100)
end

function resourceBiowaste()
  local resourceBiowaste = status.resourcePercentage("survival_resources_resourceBiowaste") * 100
  local resourceBiowaste2 = status.resourcePercentage("survival_resources_resourceBiowaste2") * 100
	
  widget.setFontColor("resourceBiowasteLabel", resourceBiowaste >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceBiowasteBar", resourceBiowaste / 100)
  widget.setProgress("resourceBiowasteBar2", resourceBiowaste2 / 100)

  if resourceBiowaste > resourceBiowaste2 then
	widget.setText("resourceBiowasteLabel", math.floor(string.format("%s", resourceBiowaste)))
  elseif resourceBiowaste2 > resourceBiowaste then
	widget.setText("resourceBiowasteLabel", math.floor(string.format("%s", resourceBiowaste2)))
  elseif resourceBiowaste == resourceBiowaste2 then
	widget.setText("resourceBiowasteLabel", math.floor(string.format("%s", resourceBiowaste)))
  end
end

function resourceStamina()
  local resourceStamina = status.resourcePercentage("survival_resources_resourceStamina") * 100
  widget.setText("resourceStaminaLabel", math.floor(string.format("%s", resourceStamina)))
  widget.setFontColor("resourceStaminaLabel", resourceStamina >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceStaminaBar", resourceStamina / 100)
end

function resourceEnergy()
  local resourceEnergy = status.resourcePercentage("energy") * 100
  widget.setText("resourceEnergyLabel", math.floor(string.format("%s", resourceEnergy)))
  widget.setFontColor("resourceEnergyLabel", resourceEnergy >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceEnergyBar", resourceEnergy / 100)
end

function resourceMana()
  local resourceMana = status.resourcePercentage("survival_resources_resourceMana") * 100
  widget.setText("resourceManaLabel", math.floor(string.format("%s", resourceMana)))
  widget.setFontColor("resourceManaLabel", resourceMana >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceManaBar", resourceMana / 100)
end

function resourceArmour()
  local resourceArmour = status.resourcePercentage("survival_resources_resourceArmour") * 100
  widget.setText("resourceArmourLabel", math.floor(string.format("%s", resourceArmour)))
  widget.setFontColor("resourceArmourLabel", resourceArmour >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceArmourBar", resourceArmour / 100)
end

function resourceAmmo()
  local resourceAmmo = status.resource("survival_resources_resourceAmmo") --* 100
  local resourceAmmoMax = status.resource("survival_resources_resourceAmmoMax")
  widget.setText("resourceAmmoLabel", math.floor(string.format(resourceAmmo)))
  widget.setFontColor("resourceAmmoLabel", resourceAmmo >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceAmmoBar", resourceAmmo / resourceAmmoMax)
end

function resourceSpecial()
  local resourceSpecial = status.resourcePercentage("survival_resources_resourceSpecial") * 100
  widget.setText("resourceSpecialLabel", math.floor(string.format("%s", resourceSpecial)))
  widget.setFontColor("resourceSpecialLabel", resourceSpecial >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceSpecialBar", resourceSpecial / 100)
end

function resourceBreath()
  local resourceBreath = status.resourcePercentage("breath") * 100
  --widget.setText("resourceSpecialLabel", math.floor(string.format("%s", resourceSpecial)))
  --widget.setFontColor("resourceSpecialLabel", resourceSpecial >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceBreathBar", resourceBreath / 100)
end

function uninit()
  --status.removeEphemeralEffect("glow")
  --status.addEphemeralEffect("glow", 5)
  status.setResourcePercentage("interfaceResourceLogic1", 1.0)
end