--A script to consume an item if the player is low on energy
function init()
  itemToBeConsumed1st = config.getParameter("itemToBeConsumed1st")
  itemToBeConsumed2nd = config.getParameter("itemToBeConsumed2nd")
  itemToBeConsumed3rd = config.getParameter("itemToBeConsumed3rd")
  itemToBeConsumed4th = config.getParameter("itemToBeConsumed4th")
  itemToBeConsumed5th = config.getParameter("itemToBeConsumed5th")
	
  itemStatusEffects1 = config.getParameter("itemStatusEffects1")
  itemStatusEffects2 = config.getParameter("itemStatusEffects2")
  itemStatusEffects3 = config.getParameter("itemStatusEffects3")
  itemStatusEffects4 = config.getParameter("itemStatusEffects4")
  itemStatusEffects5 = config.getParameter("itemStatusEffects5")
	
  self.resourcePercentageThreshold1 = config.getParameter("resourcePercentageThreshold1") / 100
  self.resourcePercentageThreshold2 = config.getParameter("resourcePercentageThreshold2") / 100
  self.resourcePercentageThreshold3 = config.getParameter("resourcePercentageThreshold3") / 100
	
  self.threshold = 0
  
  priority = 1.0
  resourceType = config.getParameter("resourceType")
  
  self.consumedItem = false
  self.itemEffectActive = false
  
  defineItemPriority()
  setItemPriority()
	
  self.cooldown = 0
  self.cooldowninterval = config.getParameter("itemConsumeInterval")
end

function update(dt)
  playerHasItem = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item}) 
  
  self.cooldown = math.max(self.cooldown - dt, 0)	
	
  local itemCount = 0
  itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item) or 0)
  
  sb.logInfo("Do we have the item in our inventory?: %s", playerHasItem)
	
  --if not status.resourceLocked(resourceType) then 
    if status.resourcePercentage(resourceType) <= self.threshold and itemCount > 0 and not self.consumedItem and self.cooldown == 0 then
	  world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item, count = 1})
      self.consumedItem = true
	  self.itemEffectActive = true
	  self.cooldown = self.cooldowninterval
    end
  --end
  
  if self.itemEffectActive then
    if playerHasItem then
	  itemEffect()
	end
	self.itemEffectActive = false
  end
  
  if self.consumedItem then
    self.consumedItem = false
  end
  
  defineItemPriority()
  setItemPriority()
end

--what item do we associate with priority?
function defineItemPriority()
  if priority == 1.0 then
    self.item = itemToBeConsumed1st
	self.threshold = self.resourcePercentageThreshold1
  elseif priority == 2.0 then
    self.item = itemToBeConsumed2nd
	self.threshold = self.resourcePercentageThreshold1
  elseif priority == 3.0 then
    self.item = itemToBeConsumed3rd
	self.threshold = self.resourcePercentageThreshold2
  elseif priority == 4.0 then
    self.item = itemToBeConsumed4th
	self.threshold = self.resourcePercentageThreshold2
  elseif priority == 5.0 then
    self.item = itemToBeConsumed5th
	self.threshold = self.resourcePercentageThreshold3
  else
    self.item = itemToBeConsumed1st
	self.threshold = self.resourcePercentageThreshold1
  end
end

--if inventory contains zero of item with associated priority, consume item next in line if available.
function setItemPriority()
  --do we have the item associated with that priority value? 
  local itemCountOfPriority1 = 0
  local itemCountOfPriority2 = 0
  local itemCountOfPriority3 = 0
  local itemCountOfPriority4 = 0
  local itemCountOfPriority5 = 0
  
  itemCountOfPriority1 = itemCountOfPriority1 + (world.entityHasCountOfItem(entity.id(), itemToBeConsumed1st) or 0)
  itemCountOfPriority2 = itemCountOfPriority2 + (world.entityHasCountOfItem(entity.id(), itemToBeConsumed2nd) or 0)
  itemCountOfPriority3 = itemCountOfPriority3 + (world.entityHasCountOfItem(entity.id(), itemToBeConsumed3rd) or 0)
  itemCountOfPriority4 = itemCountOfPriority4 + (world.entityHasCountOfItem(entity.id(), itemToBeConsumed4th) or 0)
  itemCountOfPriority5 = itemCountOfPriority5 + (world.entityHasCountOfItem(entity.id(), itemToBeConsumed5th) or 0)
  
  --ascending priority for item consumption
  if itemCountOfPriority1 == 0 and priority == 1.0 then
    priority = 2.0
  elseif itemCountOfPriority2 == 0 and priority == 2.0 then
    priority = 3.0
  elseif itemCountOfPriority3 == 0 and priority == 3.0 then
    priority = 4.0
  elseif itemCountOfPriority4 == 0 and priority == 4.0 then
    priority = 5.0
  end
  
  --what to do if you are at a high priority and pick up something with a lower priority.
  if priority >= 1.0 and itemCountOfPriority1 > 0 then
    priority = 1.0
  elseif priority >= 2.0
    and itemCountOfPriority1 == 0
    and itemCountOfPriority2 > 0 then
    priority = 2.0
  elseif priority >= 3.0
    and itemCountOfPriority1 == 0
	and itemCountOfPriority2 == 0
    and itemCountOfPriority3 > 0 then
	priority = 3.0
  elseif priority >= 4.0
    and itemCountOfPriority1 == 0
	and itemCountOfPriority2 == 0
	and itemCountOfPriority3 == 0
    and itemCountOfPriority4 > 0 then
	priority = 4.0
  end
  
end

--when we consume the item, apply is relavent status effect. All item names have status effects by the same name.
--E.g. item named "ps_energyboost1" has status effect named "ps_energyboost1"

--NOTE VANILLA ITEMS NEED TO HAVE THEIR RESPECTIVE STATUS EFFECTS APPLIED MANUALLY. Item consumption works as normal but the effect does not get applied.
--This is easily solved with priority index
function itemEffect()
  --status.addEphemeralEffect(self.item)
  if priority == 1.0 then
    status.addEphemeralEffect(itemStatusEffects1)
  elseif priority == 2.0 then
	status.addEphemeralEffect(itemStatusEffects2)	
  elseif priority == 3.0 then
	status.addEphemeralEffect(itemStatusEffects3)	
  elseif priority == 4.0 then
	status.addEphemeralEffect(itemStatusEffects4)	
  elseif priority == 5.0 then
	status.addEphemeralEffect(itemStatusEffects5)
  else
	status.addEphemeralEffect(itemStatusEffects1)
  end
end

function uninit()
  
end