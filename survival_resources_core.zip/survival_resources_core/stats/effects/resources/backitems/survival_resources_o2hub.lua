--A script to consume an item if the player is low on energy
function init()
  itemToBeConsumed1st = config.getParameter("itemToBeConsumed1st")
  
  priority = 1.0
  resourceType = config.getParameter("resourceType")
  
  self.consumedItem = false
  self.itemEffectActive = false
  
  defineItemPriority()
  setItemPriority()
end

function update(dt)
  playerHasItem = world.sendEntityMessage(entity.id(), "checkPlayerHasItem", {name = self.item}) 
  
  local itemCount = 0
  itemCount = itemCount + (world.entityHasCountOfItem(entity.id(), self.item) or 0)
  
  sb.logInfo("Do we have the item in our inventory?: %s", playerHasItem)
  
  if status.resource(resourceType) < 1 and itemCount > 0 and not self.consumedItem then
	world.sendEntityMessage(entity.id(), "playerEatYourItem", {name = self.item, count = 1})
    self.consumedItem = true
	self.itemEffectActive = true
  end
  
  if self.itemEffectActive then
    if playerHasItem then
	  itemEffect()
	end
	self.itemEffectActive = false
  end
  
  if self.consumedItem then
    self.consumedItem = false
  end
  
  defineItemPriority()
  setItemPriority()
end

--what item do we associate with priority?
function defineItemPriority()
  if priority == 1.0 then
    self.item = itemToBeConsumed1st
  else
    self.item = itemToBeConsumed1st
  end
end

--if inventory contains zero of item with associated priority, consume item next in line if available.
function setItemPriority()
  --do we have the item associated with that priority value? 
  local itemCountOfPriority1 = 0
  
  itemCountOfPriority1 = itemCountOfPriority1 + (world.entityHasCountOfItem(entity.id(), itemToBeConsumed1st) or 0)
  
  --ascending priority for item consumption
  if itemCountOfPriority1 == 0 and priority == 1.0 then
    priority = 2.0
  end
  
  --what to do if you are at a high priority and pick up something with a lower priority.
  if priority >= 1.0 and itemCountOfPriority1 > 0 then
    priority = 1.0
  end
  
end

--when we consume the item, apply is relavent status effect. All item names have status effects by the same name.
--E.g. item named "ps_energyboost1" has status effect named "ps_energyboost1"
function itemEffect()
  status.addEphemeralEffect("survival_resources_oxygenboost")
end

function uninit()
  
end