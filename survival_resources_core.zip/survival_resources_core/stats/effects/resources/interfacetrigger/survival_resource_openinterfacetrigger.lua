require "/scripts/util.lua"

function init()
  self.searchDistance = 20
  self.openInterfaceTrigger = false
  self.intervalTime = 4
end

function update(dt)
	
  self.intervalTime = math.max(self.intervalTime - dt, 0)
	
  local targets = world.entityQuery(entity.position(), self.searchDistance, {
      withoutEntityId = entity.id(),
      includedTypes = { "creature", "monster", "npc" },
      order = "nearest"
    })
	
  for _, target in ipairs(targets) do
    if entity.entityInSight(target) and (status.resourcePercentage("interfaceResourceLogic1") == 1.0) and self.intervalTime == 0 then
	  if world.entityExists(target) then
	    if world.entityAggressive(target) and world.entityCanDamage(entity.id(), target) then		
	      --status.addEphemeralEffect("glow", 2)
	      world.sendEntityMessage(entity.id(),"interact","ScriptPane","/interface/scripted/resources/survival_resources_resourceinterface3.config")
		  self.intervalTime = 4
		end		
	  end
    end
  end
	
end

function uninit()
end
