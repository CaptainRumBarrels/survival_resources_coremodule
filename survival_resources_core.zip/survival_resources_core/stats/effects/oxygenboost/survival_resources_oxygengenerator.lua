function init()

end

function update(dt)
  status.giveResource("breath", 2.5)
  if status.resourcePercentage("breath") >= 1.0 then
    status.setResourcePercentage("breath", 1.0)	
  end
end

function uninit()
  
end