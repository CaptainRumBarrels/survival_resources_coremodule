require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.visualEffectTime = 0.25
  --self.visualEffectDelay = 0.1
  self.warp = false
  
  self.blinkOut = config.getParameter("blinkOut")
  self.blinkIn = config.getParameter("blinkIn")	
end

function update(dt)
  self.visualEffectTime = math.max(self.visualEffectTime - dt, 0)
	
  if self.visualEffectTime == 0 and not self.warp then 
    if animator.animationState("blink") == "none" then
      if self.blinkOut and self.blinkIn then
        effect.setParentDirectives("")
        animator.setAnimationState("blink", "blinkin")
      else
        effect.expire()
      end
    end
    if self.blinkOut then
      animator.setAnimationState("blink", "blinkout")
      effect.setParentDirectives("?multiply=ffffff00")
      animator.playSound("activate")
    elseif self.blinkIn then
      animator.setAnimationState("blink", "blinkin")
    end	
	self.warp = true
  end
	
end

function uninit()
end
