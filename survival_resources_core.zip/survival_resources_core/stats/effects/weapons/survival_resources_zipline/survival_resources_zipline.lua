function init()

end


function update()
  mcontroller.controlParameters({
	gravityMultiplier = 0.000001,
	airFriction = 3.5,
	airForce = 10
  })
  mcontroller.controlModifiers({
    facingSuppressed = true,
    movementSuppressed = true,
	jumpingSuppressed = false
  })

end

