require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.bombBayTimeWindow = 0
  self.rateOfFire = 0
end

function update(dt)
  self.bombBayTimeWindow = math.max(0, self.bombBayTimeWindow + dt)	
  self.rateOfFire = math.max(self.rateOfFire - dt, 0)	

  if self.bombBayTimeWindow > 0.65 and self.bombBayTimeWindow < 1.65 then
	if self.rateOfFire == 0 then
      local projectileParameters = {
        power = 75,
        powerMultiplier = 1,
		speed = -40
      }
      world.spawnProjectile("survival_resources_airstrikebomb", vec2.add(entity.position(), {-0.0, -1.0}), entity.id(), {-1.0,-0.25}, false, projectileParameters)
	  self.rateOfFire = 0.12
	end
  end
end
