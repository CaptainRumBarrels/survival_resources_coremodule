require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.bombBayTimeWindow = 0
  self.rateOfFire = 0
  self.spawnSound = false
end

function update(dt)
  self.bombBayTimeWindow = math.max(0, self.bombBayTimeWindow + dt)	
  self.rateOfFire = math.max(self.rateOfFire - dt, 0)	

  if self.bombBayTimeWindow > 2.0 and self.bombBayTimeWindow < 3.5 then
	if self.rateOfFire == 0 then
	  if not self.spawnSound then
	    self.spawnSound = true
		world.spawnProjectile("survival_resources_airstrikeup", vec2.add(entity.position(), {-0.0, -1.0}), entity.id(), {-1.0,0.15}, false)
	  end
      local projectileParameters = {
        power = 75,
        powerMultiplier = 1,
		speed = -24
      }
      world.spawnProjectile("survival_resources_airstrikebomb2", vec2.add(entity.position(), {-0.0, -1.0}), entity.id(), {-1.0,-0.15}, false, projectileParameters)
	  self.rateOfFire = 0.08
	end
  end
end
