require "/scripts/vec2.lua"
require "/scripts/util.lua"

function update()
  world.spawnProjectile("survival_resources_bridgegun_droneplatform", entity.position())
end
