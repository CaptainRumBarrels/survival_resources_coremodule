function init()
  
end

function update()
	
  --world.spawnItem("survival_resources_hydrogenfuel", entity.position(), itemCount)
  --world.spawnItem("survival_resources_oxygenboost", entity.position(), itemCount)
	
  local maxValue = 7
  local minValue = 1
  local itemCount = player.hasCountOfItem("survival_resources_refinedbars")
	
  self.randomizeItem = math.floor(math.random(minValue, maxValue))
  self.randomizeQuantity = math.floor(math.random(1, 2))
	
  if self.randomizeItem == 1 or self.randomizeItem == 2 then world.spawnItem("ironbar", entity.position(), self.randomizeQuantity)
    elseif self.randomizeItem == 3 or self.randomizeItem == 4 then world.spawnItem("tungstenbar", entity.position(), 1)
    elseif self.randomizeItem == 5 or self.randomizeItem == 6 then world.spawnItem("copperbar", entity.position(), self.randomizeQuantity)
    elseif self.randomizeItem == 7 then world.spawnItem("titaniumbar", entity.position(), 1)
  end

  item.consume(1)

  --item.consume(itemCount)
end

function uninit()

end
