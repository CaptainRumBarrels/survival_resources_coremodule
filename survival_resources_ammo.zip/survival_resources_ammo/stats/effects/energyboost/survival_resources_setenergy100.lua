function init()
  script.setUpdateDelta(5)

  self.healingRate = config.getParameter("healAmount", 30) / effect.duration()
end

function update(dt)
  if status.resourcePercentage("energy") < 1.0 then
    status.setResourcePercentage("energy", 1.0)
  end
end

function uninit()
  
end