function init()
  script.setUpdateDelta(5)

  self.healingRate = config.getParameter("healAmount", 30) / effect.duration()
end

function update(dt)
  if status.resourcePercentage("energy") < 0.5 then
    status.setResourcePercentage("energy", 0.5)
  end
end

function uninit()
  
end