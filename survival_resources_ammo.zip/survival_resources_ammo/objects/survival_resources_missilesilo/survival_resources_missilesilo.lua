require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.launchPosition = vec2.add(config.getParameter("launchPosition"), entity.position())
  self.searchDistance = config.getParameter("searchDistance")
  self.sitePosition = vec2.add(entity.position(), {0.0,12.0})
  self.reloadTimer = 2
end

function update(dt)
  self.reloadTimer = math.max(self.reloadTimer - dt, 0)
  trackTarget()
end

function trackTarget()
  local targets = world.entityQuery(self.sitePosition, self.searchDistance, {
    withoutEntityId = entity.id(),
    includedTypes = { "creature", "monster", "npc" },
    order = "nearest"
  })

    for _, target in ipairs(targets) do
      if entity.entityInSight(target) then
	    if world.entityExists(target) then
	      if world.entityAggressive(target) then
		  loadWeapon()
		  end
	    end
      end
    end 
end

function loadWeapon()
  if self.reloadTimer == 0 then
    fireWeapon()
  end
end

function fireWeapon()
  animator.playSound("fire")
  world.spawnProjectile(
    "survival_resources_guardtowerrocket",
    self.launchPosition,
    entity.id(),
    {0, 1},
    false,
    {}
  )
  self.reloadTimer = 6
end

function uninit()
end
