function trigger()
  projectile.die()
  world.spawnProjectile("survival_resources_bridgegun_tempplatform", entity.position())
end
