require "/scripts/status.lua"
require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.unload = false
end

function update(dt)
  status.setResourcePercentage("survival_resources_resourceAmmoactive", 1.0)
	
  racialBonus()
	
  if not player.primaryHandItem() or not player.altHandItem() then
    status.setResourcePercentage("survival_resources_resourceAmmo", 0.0)
  end
  --status.setResourcePercentage("survival_resources_resourceAmmoMax", status.resourcePercentage("survival_resources_resourceAmmo"))
end

function racialBonus()
  if world.entitySpecies(player.id()) == "novakid" then
    if (status.resourcePercentage("survival_resources_resourceAmmo") > 0.0) then
	  status.addEphemeralEffect("rage", 1.0)
	else
	  status.removeEphemeralEffect("rage")
	end  	
  end
end

function uninit()
	
end