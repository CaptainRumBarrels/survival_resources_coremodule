require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()

end

function update(dt)
	
 -- local projectileParameters = {
   -- power = 4,
   -- powerMultiplier = 1
  --}
  --if projectile.collision() then 
   -- world.spawnProjectile("grenade", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {0.0,3.0}, false, projectileParameters)
    --world.spawnProjectile("survival_resources_stormcloudrain2", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {0.1,-1.0}, false, projectileParameters)
	
  --end
end

function uninit()
  local projectileParameters = {
    power = 4,
    powerMultiplier = 1
  }
  world.spawnProjectile("survival_resources_stormcloud3", vec2.add(entity.position(), {0.0, 0.0}), entity.id(), {0.0,1.0}, false, projectileParameters)
end