function init()
  animator.setAnimationState("aura", "windup")
end
