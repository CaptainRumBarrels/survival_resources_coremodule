function init()
  
end

function update()
  if status.resourcePercentage("survival_resources_resourceManaUnlock") == 1 then
	if status.resourcePercentage("survival_resources_resourceManaUnlock2") == 0
      animator.playSound("activate")
	  status.setResourcePercentage("survival_resources_resourceManaUnlock2", 1.0)
	end
  end
end

function uninit()
  
end