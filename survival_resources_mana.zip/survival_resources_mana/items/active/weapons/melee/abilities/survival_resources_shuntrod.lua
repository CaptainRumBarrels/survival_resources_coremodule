require "/items/active/weapons/melee/abilities/survival_resources_meleeslash2.lua"

-- Spear stab attack
-- Extends normal melee attack and adds a hold state
survival_resources_shuntrod = MeleeSlash:new()

function survival_resources_shuntrod:init()
  MeleeSlash.init(self)

  self.holdDamageConfig = sb.jsonMerge(self.damageConfig, self.holdDamageConfig)
  self.holdDamageConfig.baseDamage = self.holdDamageMultiplier * self.damageConfig.baseDamage
end

function survival_resources_shuntrod:fire()
  MeleeSlash.fire(self)

  if self.fireMode == "primary" and self.allowHold ~= false then
    self:setState(self.hold)
  end
end

function survival_resources_shuntrod:hold()
  self.weapon:setStance(self.stances.hold)
  self.weapon:updateAim()

  while self.fireMode == "primary" do
    local damageArea = partDamageArea("blade")
    self.weapon:setDamage(self.holdDamageConfig, damageArea)
	status.overConsumeResource("survival_resources_resourceMana", 0.1)
    coroutine.yield()
  end

  self.cooldownTimer = self:cooldownTime()
end
